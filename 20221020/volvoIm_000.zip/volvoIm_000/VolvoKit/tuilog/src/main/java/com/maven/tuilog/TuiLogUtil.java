package com.maven.tuilog;

import android.util.Log;

public class TuiLogUtil {

    public static void i(String logcontent){
        Log.i("mavenTest",logcontent);
    }

    public static void e(String logcontent){
        Log.i("mavenTest == e",logcontent);
    }
}
