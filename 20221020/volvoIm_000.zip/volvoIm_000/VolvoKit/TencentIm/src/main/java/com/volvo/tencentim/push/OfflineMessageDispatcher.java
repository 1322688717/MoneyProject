package com.volvo.tencentim.push;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.tencent.qcloud.util.VolvoImConstant;
import com.volvo.tencentim.utils.BrandUtil;
import com.volvo.tencentim.utils.DemoLog;

import java.util.Map;
import java.util.Set;

public class OfflineMessageDispatcher {

    private static final String TAG = OfflineMessageDispatcher.class.getSimpleName();
    private static final String OEMMessageKey = "ext";
    private static final String TPNSMessageKey = "customContent";
    private static final String XIAOMIMessageKey = "key_message";

    public static OfflineMessageBean parseOfflineMessage(Intent intent) {
        DemoLog.i(TAG, "intent: " + intent);
        if (intent == null) {
            return null;
        }

        DemoLog.i(TAG, "parse OEM push");
        Bundle bundle = intent.getExtras();
        DemoLog.i(TAG, "bundle: " + bundle);
        if (bundle == null) {
            // TPNS 的透传参数数据格式为 customContent:{data}
            Uri uri = intent.getData();
            if (uri == null) {
                DemoLog.i(TAG, "intent.getData() uri is null");
                return null;
            } else {
                return parseOfflineMessageTPNS(intent);
            }
        } else {
            String ext = bundle.getString(OEMMessageKey);
            DemoLog.i(TAG, "push custom data ext: " + ext);
            if (TextUtils.isEmpty(ext)) {
                if (BrandUtil.isBrandXiaoMi()) {
                    ext = getXiaomiMessage(bundle);
                    return getOfflineMessageBeanFromContainer(ext);
                } else if (BrandUtil.isBrandOppo()) {
                    ext = getOPPOMessage(bundle);
                    return getOfflineMessageBean(ext);
                }
                DemoLog.i(TAG, "ext is null");
                return null;
            } else {
                return getOfflineMessageBeanFromContainer(ext);
            }
        }
    }


    private static String getXiaomiMessage(Bundle bundle) {
        Map extra = null;
        try {
            Object objectMessage = bundle.getSerializable(XIAOMIMessageKey);
            extra = (Map) objectMessage.getClass().getMethod("getExtra").invoke(objectMessage);
        } catch (Exception e) {
            DemoLog.e(TAG, "getXiaomiMessage e = " + e);
        }

        if (extra == null) {
            DemoLog.e(TAG, "getXiaomiMessage is null");
            return "";
        }

        DemoLog.i(TAG, "getXiaomiMessage ext: " + extra.get("ext").toString());
        return extra.get("ext").toString();
    }

    private static String getOPPOMessage(Bundle bundle) {
        Set<String> set = bundle.keySet();
        if (set != null) {
            for (String key : set) {
                Object value = bundle.get(key);
                DemoLog.i(TAG, "push custom data key: " + key + " value: " + value);
                if (TextUtils.equals("entity", key)) {
                    return value.toString();
                }
            }
        }
        return null;
    }

    private static OfflineMessageBean parseOfflineMessageTPNS(Intent intent) {
        DemoLog.i(TAG, "parse TPNS push");
        //intent uri
        Uri uri = intent.getData();
        if (uri == null) {
            DemoLog.i(TAG, "intent.getData() uri is null");
        } else {
            DemoLog.i(TAG, "parseOfflineMessageTPNS get data uri: " + uri);
            String ext = uri.getQueryParameter(TPNSMessageKey);
            DemoLog.i(TAG, "push custom data ext: " + ext);
            if (!TextUtils.isEmpty(ext)) {
                return getOfflineMessageBeanFromContainer(ext);
            } else {
                DemoLog.i(TAG, "TextUtils.isEmpty(ext)");
            }
        }
        return null;
    }

    private static OfflineMessageBean getOfflineMessageBeanFromContainer(String ext) {
        if (TextUtils.isEmpty(ext)) {
            return null;
        }
        OfflineMessageContainerBean bean = null;
        try {
            bean = new Gson().fromJson(ext, OfflineMessageContainerBean.class);
        } catch (Exception e) {
            DemoLog.w(TAG, "getOfflineMessageBeanFromContainer: " + e.getMessage());
        }
        if (bean == null) {
            return null;
        }
        return offlineMessageBeanValidCheck(bean.entity);
    }

    private static OfflineMessageBean getOfflineMessageBean(String ext) {
        if (TextUtils.isEmpty(ext)) {
            return null;
        }
        OfflineMessageBean bean = new Gson().fromJson(ext, OfflineMessageBean.class);
        return offlineMessageBeanValidCheck(bean);
    }

    private static OfflineMessageBean offlineMessageBeanValidCheck(OfflineMessageBean bean) {
        if (bean == null) {
            return null;
        } else if (bean.version != 1
                || (bean.action != OfflineMessageBean.REDIRECT_ACTION_CHAT
                && bean.action != OfflineMessageBean.REDIRECT_ACTION_CALL)) {
            PackageManager packageManager = VolvoImConstant.application.getPackageManager();
            String label = String.valueOf(packageManager.getApplicationLabel(VolvoImConstant.application.getApplicationInfo()));
//            ToastUtil.toastLongMessage(Constant.application.getString(R.string.you_app) + label + Constant.application.getString(R.string.low_version));
            DemoLog.e(TAG, "unknown version: " + bean.version + " or action: " + bean.action);
            return null;
        }
        return bean;
    }

    public static void updateBadge(final Context context, final int number) {
        if (!BrandUtil.isBrandHuawei()) {
            return;
        }
        DemoLog.i(TAG, "huawei badge = " + number);
        try {
            Bundle extra = new Bundle();
            extra.putString("package", context.getPackageName());
            extra.putString("class", "se.volvo.vcc.ui.activities.SplashActivity");
            extra.putInt("badgenumber", number);
            context.getContentResolver().call(Uri.parse("content://com.huawei.android.launcher.settings/badge/"), "change_badge", null, extra);
        } catch (Exception e) {
            DemoLog.w(TAG, "huawei badge exception: " + e.getLocalizedMessage());
        }
    }


}
