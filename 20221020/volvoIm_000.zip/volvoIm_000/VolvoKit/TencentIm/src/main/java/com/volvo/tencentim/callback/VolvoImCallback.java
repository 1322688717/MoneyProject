package com.volvo.tencentim.callback;

public abstract class VolvoImCallback {
    public abstract void onSuccess();

    public abstract void onError(int errorCode, String errorMessage);

    public static void onSuccess(VolvoImCallback callback) {
        if (callback != null) {
            callback.onSuccess();
        }
    }

    public static void onError(VolvoImCallback callback, int errorCode, String errorMessage) {
        if (callback != null) {
            callback.onError(errorCode, errorMessage);
        }
    }
}
