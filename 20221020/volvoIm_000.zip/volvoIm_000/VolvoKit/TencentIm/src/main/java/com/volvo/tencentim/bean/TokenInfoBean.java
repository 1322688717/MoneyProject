package com.volvo.tencentim.bean;

import java.io.Serializable;

/**
 * 登录得到的token信息
 */
public class TokenInfoBean implements Serializable {

    /**
     * fourInOne : {"baseUrl":"https://tchatapi.wedochina.cn","apiPwd":"RLIMB7UHYGDtZhBwvolvo","apiUid":"volvoIMtest","apiPathSurvey":"/api/services/app/IM/Survey"}
     */
    private FourInOneBean fourInOne;

    public static class FourInOneBean implements Serializable {
        /**
         * baseUrl : https://tchatapi.wedochina.cn
         * apiPwd : RLIMB7UHYGDtZhBwvolvo
         * apiUid : volvoIMtest
         * apiPathSurvey : /api/services/app/IM/Survey
         */

        private String baseUrl;
        private String apiPwd;
        private String apiUid;
        private String apiPathSurvey;

        public String getBaseUrl() {
            return baseUrl;
        }

        public void setBaseUrl(String baseUrl) {
            this.baseUrl = baseUrl;
        }

        public String getApiPwd() {
            return apiPwd;
        }

        public void setApiPwd(String apiPwd) {
            this.apiPwd = apiPwd;
        }

        public String getApiUid() {
            return apiUid;
        }

        public void setApiUid(String apiUid) {
            this.apiUid = apiUid;
        }

        public String getApiPathSurvey() {
            return apiPathSurvey;
        }

        public void setApiPathSurvey(String apiPathSurvey) {
            this.apiPathSurvey = apiPathSurvey;
        }
    }

    public FourInOneBean getFourInOne() {
        return fourInOne;
    }

    public void setFourInOne(FourInOneBean fourInOne) {
        this.fourInOne = fourInOne;
    }
}
