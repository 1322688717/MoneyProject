package com.volvo.tencentim.callback;

public interface UnReadMessageListener {
    void unReadTotalMessage(int unReadNummber);
}
