package com.volvo.tencentim.utils;

public class PushPrivateConstants {

    /****** 华为离线推送参数start ******/
    // 在腾讯云控制台上传第三方推送证书后分配的证书ID
    public static long HW_PUSH_BUZID = 24569;
    // 角标参数，默认为应用的 launcher 界面的类名
    public static  String BADGE_CLASS_NAME = "com.tencent.qcloud.tim.demo.SplashActivity";
    /****** 华为离线推送参数end ******/

    /****** 小米离线推送参数start ******/
    // 在腾讯云控制台上传第三方推送证书后分配的证书ID
    public static  long XM_PUSH_BUZID = 0;
    // 小米开放平台分配的应用APPID及APPKEY
    public static  String XM_PUSH_APPID = "";
    public static  String XM_PUSH_APPKEY = "";
    /****** 小米离线推送参数end ******/

    /****** vivo离线推送参数start ******/
    // 在腾讯云控制台上传第三方推送证书后分配的证书ID
    public static  long VIVO_PUSH_BUZID = 0;
    // 海外证书 ID，不需要直接删掉
    public static  long VIVO_PUSH_BUZID_ABROAD = 0;
    /****** vivo离线推送参数end ******/

    /****** oppo离线推送参数start ******/
    // 在腾讯云控制台上传第三方推送证书后分配的证书ID
    public static  long OPPO_PUSH_BUZID = 0;
    // oppo开放平台分配的应用APPID及APPKEY
    public static  String OPPO_PUSH_APPKEY = "";
    public static  String OPPO_PUSH_APPSECRET = "";
    /****** oppo离线推送参数end ******/
}
