package com.volvo.tencentim.utils;

import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.tencent.imsdk.v2.V2TIMCallback;
import com.tencent.imsdk.v2.V2TIMManager;
import com.tencent.imsdk.v2.V2TIMOfflinePushConfig;
import com.tencent.qcloud.tuicore.util.ToastUtil;
import com.volvo.tencentim.bean.VolvoDemoLoginBean;
import com.volvo.tencentim.bean.VolvoLoginBean;
import com.volvo.tencentim.push.OfflineMessageBean;

/**
 * 离线消息管理类
 */
public class OfflineUtil {

    /**
     * 注册离线推送
     */
    public static void registerPush(String pushToken) {
        V2TIMOfflinePushConfig v2TIMOfflinePushConfig = null;
        long businessID;
        if (BrandUtil.isBrandXiaoMi()) {
            businessID = PushPrivateConstants.XM_PUSH_BUZID;
        } else if (BrandUtil.isBrandHuawei()) {
            businessID = PushPrivateConstants.HW_PUSH_BUZID;
        } else if (BrandUtil.isBrandOppo()) {
            businessID = PushPrivateConstants.OPPO_PUSH_BUZID;
        } else if (BrandUtil.isBrandVivo()) {
            businessID = PushPrivateConstants.VIVO_PUSH_BUZID;
        } else {
            return;
        }
        v2TIMOfflinePushConfig = new V2TIMOfflinePushConfig(businessID, pushToken);
        /**
         * 上报腾讯后台
         */
        V2TIMManager.getOfflinePushManager().setOfflinePushConfig(v2TIMOfflinePushConfig, new V2TIMCallback() {
            @Override
            public void onError(int code, String desc) {
//                ToastUtil.toastShortMessage("token注册失败=="+code+"  "+desc);
//                Log.i("tencentImPush -- error",code+"  "+desc);
            }

            @Override
            public void onSuccess() {
//                ToastUtil.toastShortMessage("token上传成功");
//                Log.i("tencentImPush","-- success");
            }
        });
    }

    /**
     * 注销离线推送
     */
    public static void unRegisterPush(){
//        TUIOfflinePushManager.getInstance().unRegisterPush(VolvoImConstant.application,V2TIMManager.getInstance().getLoginUser());
    }

    /**
     * APP接入使用
     * 初始化推送信息,暂不删除
     */
    public static void initVolvoPushParams(VolvoLoginBean volvoInfo) {
        //推送消息获取
        VolvoLoginBean.DataBean.AndroidPushVOBean anPushBean = volvoInfo.getData().getAndroidPushVO();
        //华为
        PushPrivateConstants.HW_PUSH_BUZID = getCertLong(anPushBean.getHwCert());
        //小米
        PushPrivateConstants.XM_PUSH_BUZID = getCertLong(anPushBean.getXmCert());
        PushPrivateConstants.XM_PUSH_APPID = anPushBean.getXmAppID();
        PushPrivateConstants.XM_PUSH_APPKEY = anPushBean.getXmAppKey();
        //Vivo
        PushPrivateConstants.VIVO_PUSH_BUZID = getCertLong(anPushBean.getVivoCert());
        //oppo
        PushPrivateConstants.OPPO_PUSH_BUZID = getCertLong(anPushBean.getOppoCert());
        PushPrivateConstants.OPPO_PUSH_APPKEY = anPushBean.getOppoAppID();
        PushPrivateConstants.OPPO_PUSH_APPSECRET = anPushBean.getOppoAppKey();
    }

    /**
     * Demo使用
     * 初始化推送信息
     */
    public static void initDemoPushParams(VolvoDemoLoginBean volvoInfo) {
        //推送消息获取
        VolvoDemoLoginBean.DataBean.AndroidPushVOBean anPushBean = volvoInfo.getData().getAndroidPushVO();
        //华为
        PushPrivateConstants.HW_PUSH_BUZID = getCertLong(anPushBean.getHwCert());
        //小米
        PushPrivateConstants.XM_PUSH_BUZID = getCertLong(anPushBean.getXmCert());
        PushPrivateConstants.XM_PUSH_APPID = anPushBean.getXmAppID();
        PushPrivateConstants.XM_PUSH_APPKEY = anPushBean.getXmAppKey();
        //Vivo
        PushPrivateConstants.VIVO_PUSH_BUZID = getCertLong(anPushBean.getVivoCert());
        //oppo
        PushPrivateConstants.OPPO_PUSH_BUZID = getCertLong(anPushBean.getOppoCert());
        PushPrivateConstants.OPPO_PUSH_APPKEY = anPushBean.getOppoAppID();
        PushPrivateConstants.OPPO_PUSH_APPSECRET = anPushBean.getOppoAppKey();
    }

    /**
     * 证书类型转换为long
     *
     * @param certString
     * @return
     */
    private static long getCertLong(String certString) {
        if (TextUtils.isEmpty(certString)) {
            return 0;
        }
        try {
            return Long.valueOf(certString);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * 判断是否为腾讯IM离线消息
     * @return
     */
    public static boolean isOfflineMsg(String offlineJson){
        if(TextUtils.isEmpty(offlineJson)){
            return false;
        }
        if(!isJson(offlineJson)){
            return false;
        }
        OfflineMessageBean bean = new Gson().fromJson(offlineJson,OfflineMessageBean.class);
        if(null == bean ){
            return false;
        }
        return true;
    }

    /**
     * 判断string字符串是不是json格式
     * @param content
     * @return
     */
    public static boolean isJson(String content) {
        try {
            if(content.contains("[")&&content.contains("]")){
                new org.json.JSONArray(content);
                return true;
            }else{
                new org.json.JSONObject(content);
                return true;
            }

        } catch (org.json.JSONException e) {
            return false;
        }
    }
}
