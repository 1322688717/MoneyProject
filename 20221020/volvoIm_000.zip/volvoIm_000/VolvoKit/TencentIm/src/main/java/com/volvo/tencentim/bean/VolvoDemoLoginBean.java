package com.volvo.tencentim.bean;

import java.io.Serializable;

public class VolvoDemoLoginBean implements Serializable {

    /**
     * code : 0
     * msg : IM初始化成功！
     * data : {"sdkID":1400668500,"androidPushVO":{"mzAppID":"7777","oppoAppID":"131313","vivoCert":"99999","xmAppID":"44444","oppoCert":"121212","mzCert":"66666","hwCert":"22222","oppoAppKey":"1414","mzAppKey":"88888","googleCert":"1020000","xmCert":"33333","xmAppKey":"55555"},"customerID":"1_51","iosPushVO":{"certPro":"1111","certDev":"33713"},"customerServiceID":"exclusive_kf_01","token":"eJyrVgrxCdbLTEnNK8lMy0wtUrJSMow3NVTSAYunVhRkFqUqWVmYmRgYQISKM9OBaiIjyzLyi8wCzXxz-Qydk82DTEO8-Yr9qlzCTLKrqjK9U1zdckyLgsoKqxxtoWaVgQ030jOA8ksyc4EmG5qZmhsbGxhbmEKNT8lOLCjITAHKAK00M7MwNTCoBQAb8TAw"}
     */

    private int code;
    private String msg;
    private DataBean data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * sdkID : 1400668500
         * androidPushVO : {"mzAppID":"7777","oppoAppID":"131313","vivoCert":"99999","xmAppID":"44444","oppoCert":"121212","mzCert":"66666","hwCert":"22222","oppoAppKey":"1414","mzAppKey":"88888","googleCert":"1020000","xmCert":"33333","xmAppKey":"55555"}
         * customerID : 1_51
         * iosPushVO : {"certPro":"1111","certDev":"33713"}
         * customerServiceID : exclusive_kf_01
         * token : eJyrVgrxCdbLTEnNK8lMy0wtUrJSMow3NVTSAYunVhRkFqUqWVmYmRgYQISKM9OBaiIjyzLyi8wCzXxz-Qydk82DTEO8-Yr9qlzCTLKrqjK9U1zdckyLgsoKqxxtoWaVgQ030jOA8ksyc4EmG5qZmhsbGxhbmEKNT8lOLCjITAHKAK00M7MwNTCoBQAb8TAw
         */

        private int sdkID;
        private AndroidPushVOBean androidPushVO;
        private String customerID;
        private IosPushVOBean iosPushVO;
        private String customerServiceID;
        private String token;

        public int getSdkID() {
            return sdkID;
        }

        public void setSdkID(int sdkID) {
            this.sdkID = sdkID;
        }

        public AndroidPushVOBean getAndroidPushVO() {
            return androidPushVO;
        }

        public void setAndroidPushVO(AndroidPushVOBean androidPushVO) {
            this.androidPushVO = androidPushVO;
        }

        public String getCustomerID() {
            return customerID;
        }

        public void setCustomerID(String customerID) {
            this.customerID = customerID;
        }

        public IosPushVOBean getIosPushVO() {
            return iosPushVO;
        }

        public void setIosPushVO(IosPushVOBean iosPushVO) {
            this.iosPushVO = iosPushVO;
        }

        public String getCustomerServiceID() {
            return customerServiceID;
        }

        public void setCustomerServiceID(String customerServiceID) {
            this.customerServiceID = customerServiceID;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public static class AndroidPushVOBean {
            /**
             * mzAppID : 7777
             * oppoAppID : 131313
             * vivoCert : 99999
             * xmAppID : 44444
             * oppoCert : 121212
             * mzCert : 66666
             * hwCert : 22222
             * oppoAppKey : 1414
             * mzAppKey : 88888
             * googleCert : 1020000
             * xmCert : 33333
             * xmAppKey : 55555
             */

            private String mzAppID;
            private String oppoAppID;
            private String vivoCert;
            private String xmAppID;
            private String oppoCert;
            private String mzCert;
            private String hwCert;
            private String oppoAppKey;
            private String mzAppKey;
            private String googleCert;
            private String xmCert;
            private String xmAppKey;

            public String getMzAppID() {
                return mzAppID;
            }

            public void setMzAppID(String mzAppID) {
                this.mzAppID = mzAppID;
            }

            public String getOppoAppID() {
                return oppoAppID;
            }

            public void setOppoAppID(String oppoAppID) {
                this.oppoAppID = oppoAppID;
            }

            public String getVivoCert() {
                return vivoCert;
            }

            public void setVivoCert(String vivoCert) {
                this.vivoCert = vivoCert;
            }

            public String getXmAppID() {
                return xmAppID;
            }

            public void setXmAppID(String xmAppID) {
                this.xmAppID = xmAppID;
            }

            public String getOppoCert() {
                return oppoCert;
            }

            public void setOppoCert(String oppoCert) {
                this.oppoCert = oppoCert;
            }

            public String getMzCert() {
                return mzCert;
            }

            public void setMzCert(String mzCert) {
                this.mzCert = mzCert;
            }

            public String getHwCert() {
                return hwCert;
            }

            public void setHwCert(String hwCert) {
                this.hwCert = hwCert;
            }

            public String getOppoAppKey() {
                return oppoAppKey;
            }

            public void setOppoAppKey(String oppoAppKey) {
                this.oppoAppKey = oppoAppKey;
            }

            public String getMzAppKey() {
                return mzAppKey;
            }

            public void setMzAppKey(String mzAppKey) {
                this.mzAppKey = mzAppKey;
            }

            public String getGoogleCert() {
                return googleCert;
            }

            public void setGoogleCert(String googleCert) {
                this.googleCert = googleCert;
            }

            public String getXmCert() {
                return xmCert;
            }

            public void setXmCert(String xmCert) {
                this.xmCert = xmCert;
            }

            public String getXmAppKey() {
                return xmAppKey;
            }

            public void setXmAppKey(String xmAppKey) {
                this.xmAppKey = xmAppKey;
            }
        }

        public static class IosPushVOBean {
            /**
             * certPro : 1111
             * certDev : 33713
             */

            private String certPro;
            private String certDev;

            public String getCertPro() {
                return certPro;
            }

            public void setCertPro(String certPro) {
                this.certPro = certPro;
            }

            public String getCertDev() {
                return certDev;
            }

            public void setCertDev(String certDev) {
                this.certDev = certDev;
            }
        }
    }
}
