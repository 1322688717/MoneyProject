package com.volvo.tencentim;

import static com.tencent.imsdk.base.ThreadUtils.runOnUiThread;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import com.google.gson.Gson;
import com.tencent.imsdk.v2.V2TIMConversation;
import com.tencent.imsdk.v2.V2TIMConversationListener;
import com.tencent.imsdk.v2.V2TIMManager;
import com.tencent.imsdk.v2.V2TIMSDKConfig;
import com.tencent.imsdk.v2.V2TIMValueCallback;
import com.tencent.qcloud.http.MposRequest;
import com.tencent.qcloud.http.NetworkCallback;
import com.tencent.qcloud.tuicore.TUIConstants;
import com.tencent.qcloud.tuicore.TUICore;
import com.tencent.qcloud.tuicore.TUILogin;
import com.tencent.qcloud.tuicore.TUIThemeManager;
import com.tencent.qcloud.tuicore.interfaces.TUICallback;
import com.tencent.qcloud.tuicore.util.FileUtil;
import com.tencent.qcloud.tuicore.util.ToastUtil;
import com.tencent.qcloud.util.SpUtil;
import com.tencent.qcloud.util.VIMEntranceType;
import com.tencent.qcloud.util.VolvoChatCallback;
import com.tencent.qcloud.util.VolvoImConstant;
import com.volvo.tencentim.bean.TokenInfoBean;
import com.volvo.tencentim.bean.VolvoDemoLoginBean;
import com.volvo.tencentim.bean.VolvoLoginBean;
import com.volvo.tencentim.callback.UnReadMessageListener;
import com.volvo.tencentim.callback.VolvoImCallback;
import com.volvo.tencentim.push.OfflineMessageBean;
import com.volvo.tencentim.push.OfflineMessageDispatcher;
import com.volvo.tencentim.utils.CustomProgressDialog;
import com.volvo.tencentim.utils.LogUtils;
import com.tencent.qcloud.tuicore.util.MD5Utils;
import com.volvo.tencentim.utils.OfflineUtil;

import java.util.Map;
import java.util.UUID;

import okhttp3.Interceptor;

public class VolvoImKit {

    private static class SingletonHolder {
        private static VolvoImKit INSTANCE = new VolvoImKit();
    }

    public static VolvoImKit get() {
        return SingletonHolder.INSTANCE;
    }

    /**
     * 初始化IM
     */
    public boolean initIm(Application application, VolvoSDKConfig config) {
        //全局Application对象
        VolvoImConstant.application = application;
        V2TIMSDKConfig v2Config = new V2TIMSDKConfig();
        // 指定 log 输出级别
        v2Config.setLogLevel(V2TIMSDKConfig.V2TIM_LOG_NONE);
        if (TextUtils.isEmpty(config.packaggeName)) {
            return false;
        } else {
            //中文语言
            TUIThemeManager.getInstance().changeLanguage(application, "zh");
            //包名
            SpUtil.getInstance().putString(VolvoImConstant.SP_APPREMARK, config.packaggeName);
            return true;
        }
    }

    /**
     * 设置VolvoIm域名,登录前调用
     */
    public void setVolvoDomain(String doMainUrl) {
        if (!TextUtils.isEmpty(doMainUrl)) {
            //域名设置
            SpUtil.getInstance().putString(VolvoImConstant.SP_DOMAINURL, doMainUrl);
        }
    }

    /**
     * 添加拦截器
     */
    public void addInterceptor(Interceptor interceptor) {
        VolvoImConstant.verifyInterceptor = interceptor;
    }

    /**
     * 更新头像信息
     */
    public void refreshNewHeader(String newHeaderUrl) {
        if (!TextUtils.isEmpty(newHeaderUrl)) {
            SpUtil.getInstance().putString(VolvoImConstant.SP_MEMBERURL, newHeaderUrl);
        }
    }

    /**
     * 更新请求HeaderToken
     */
    public void refreshHeaderToken(String Authorization,String X_Token){
        VolvoImConstant.header_Authorization = Authorization;
        VolvoImConstant.header_X_Token = X_Token;
    }

    /**
     * 测试调用
     * IM登录
     */
    public void loginDemo(Map<String, Object> params, final VolvoImCallback callback) {
        if (null == VolvoImConstant.application) {
            ToastUtil.toastShortMessage("请完成初始化");
            return;
        }
        if (null == params || TextUtils.isEmpty((CharSequence) params.get(VolvoImConstant.VOLVO_MEMBERID)) || TextUtils.isEmpty((CharSequence) params.get(VolvoImConstant.VOLVO_MEMBERNAME))
                || TextUtils.isEmpty((CharSequence) params.get(VolvoImConstant.VOLVO_MEMBERURL))) {
            ToastUtil.toastShortMessage("参数设置错误");
            return;
        }
        SpUtil.getInstance().putBoolean(VolvoImConstant.SP_ISDEMOTEST, true);
        //登录数据记录
        SpUtil.getInstance().putString(VolvoImConstant.SP_MEMBERID, (String) params.get(VolvoImConstant.VOLVO_MEMBERID));
        SpUtil.getInstance().putString(VolvoImConstant.SP_MEMBERNAME, (String) params.get(VolvoImConstant.VOLVO_MEMBERNAME));
        SpUtil.getInstance().putString(VolvoImConstant.SP_MEMBERURL, (String) params.get(VolvoImConstant.VOLVO_MEMBERURL));
        LogUtils.debugInfo("demo调试==开始调用==");
        MposRequest.getInstance().getDemoLoginInfo(params, 1, new NetworkCallback() {
            @Override
            public void success(String result) {
                LogUtils.debugInfo("demo调试==登录成功==" + result);
                VolvoDemoLoginBean volvoInfo = new Gson().fromJson(result, VolvoDemoLoginBean.class);
                if (0 == volvoInfo.getCode()) {
                    String imToken = volvoInfo.getData().getToken();
                    //记录登录信息
                    SpUtil.getInstance().putString(VolvoImConstant.SP_CUSTOMERID, volvoInfo.getData().getCustomerID());
                    SpUtil.getInstance().putString(VolvoImConstant.SP_TOKEN, imToken);
                    SpUtil.getInstance().putString(VolvoImConstant.SP_CUSTOMER_SERVICEID, volvoInfo.getData().getCustomerServiceID());
                    SpUtil.getInstance().putInt(VolvoImConstant.SP_SDKAPPID, volvoInfo.getData().getSdkID());
                    //解析得到token信息
                    try {
                        String fourInOne = volvoInfo.getData().getAndroidPushVO().getGoogleCert();
                        TokenInfoBean tokenInfoBean = new Gson().fromJson(fourInOne,TokenInfoBean.class);
                        VolvoImConstant.header_apiuid = tokenInfoBean.getFourInOne().getApiUid();
                        VolvoImConstant.token_satisfactionBaseUrl = tokenInfoBean.getFourInOne().getBaseUrl();
                        VolvoImConstant.token_satisfactionApiUrl = tokenInfoBean.getFourInOne().getApiPathSurvey();
                        VolvoImConstant.token_apiPwd = tokenInfoBean.getFourInOne().getApiPwd();
                        VolvoImConstant.header_noncestr = UUID.randomUUID().toString();
                    }catch (Exception e){
                    }
                    TUILogin.login(VolvoImConstant.application, volvoInfo.getData().getSdkID(), volvoInfo.getData().getCustomerID(),imToken, new TUICallback() {
                        @Override
                        public void onSuccess() {
                            //初始化推送消息
                            OfflineUtil.initDemoPushParams(volvoInfo);
                            //设置日志级别
                            V2TIMSDKConfig logConfig = new V2TIMSDKConfig();
                            logConfig.setLogLevel(VolvoSDKConfig.logLevel);
                            V2TIMManager.getInstance().initSDK(VolvoImConstant.application, SpUtil.getInstance().getInt(VolvoImConstant.SP_SDKAPPID, 0), logConfig);
                            //离线推送会通过通知自动注册，不用手动操作
                            VolvoImCallback.onSuccess(callback);
                        }

                        @Override
                        public void onError(int errorCode, String errorMessage) {
                            VolvoImCallback.onError(callback, errorCode, errorMessage);
                        }
                    });
                } else {
                    VolvoImCallback.onError(callback, volvoInfo.getCode(), volvoInfo.getMsg());
                }
            }

            @Override
            public void error(int errorCode, String errormsg) {
                VolvoImCallback.onError(callback, errorCode, errormsg);
            }
        });
    }

    /**
     * APP接入调用
     * IM登录
     */
    public void loginVolvoIm(Map<String, Object> params, final VolvoImCallback callback) {
        if (null == VolvoImConstant.application) {
            VolvoImCallback.onError(callback, 2, "初始化失败");
            return;
        }
        if (null == params || TextUtils.isEmpty((CharSequence) params.get(VolvoImConstant.VOLVO_MEMBERID))) {
            VolvoImCallback.onError(callback, 3, "参数设置错误");
            return;
        }
        if (TextUtils.isEmpty((String) params.get("Authorization")) || TextUtils.isEmpty((String) params.get("X-Token"))) {
            VolvoImCallback.onError(callback, 4, "token设置错误");
            return;
        }
        VolvoImConstant.header_Authorization = (String) params.get("Authorization");
        VolvoImConstant.header_X_Token = (String) params.get("X-Token");
        SpUtil.getInstance().putBoolean(VolvoImConstant.SP_ISDEMOTEST, false);
        //登录数据记录
        SpUtil.getInstance().putString(VolvoImConstant.SP_MEMBERID, (String) params.get(VolvoImConstant.VOLVO_MEMBERID));
        SpUtil.getInstance().putString(VolvoImConstant.SP_MEMBERNAME, (String) params.get(VolvoImConstant.VOLVO_MEMBERNAME));
        SpUtil.getInstance().putString(VolvoImConstant.SP_MEMBERURL, (String) params.get(VolvoImConstant.VOLVO_MEMBERURL));
        //关闭自己的日志打印
        LogUtils.setLog(false);

        MposRequest.getInstance().getVolvoLoginInfo(params, 1, new NetworkCallback() {
            @Override
            public void success(String result) {
                VolvoLoginBean volvoInfo = new Gson().fromJson(result, VolvoLoginBean.class);
                if (volvoInfo.isSuccess()) {
                    String imToken = volvoInfo.getData().getToken();
                    //记录登录信息
                    SpUtil.getInstance().putString(VolvoImConstant.SP_CUSTOMERID, volvoInfo.getData().getCustomerID());
                    SpUtil.getInstance().putString(VolvoImConstant.SP_TOKEN, imToken);
                    SpUtil.getInstance().putString(VolvoImConstant.SP_CUSTOMER_SERVICEID, volvoInfo.getData().getCustomerServiceID());
                    int loginSdkId = Integer.valueOf(volvoInfo.getData().getSdkID());
                    SpUtil.getInstance().putInt(VolvoImConstant.SP_SDKAPPID, loginSdkId);
                    //解析得到token信息
                    try {
                        String fourInOne = volvoInfo.getData().getAndroidPushVO().getGoogleCert();
                        TokenInfoBean tokenInfoBean = new Gson().fromJson(fourInOne,TokenInfoBean.class);
                        VolvoImConstant.header_apiuid = tokenInfoBean.getFourInOne().getApiUid();
                        VolvoImConstant.token_satisfactionBaseUrl = tokenInfoBean.getFourInOne().getBaseUrl();
                        VolvoImConstant.token_satisfactionApiUrl = tokenInfoBean.getFourInOne().getApiPathSurvey();
                        VolvoImConstant.token_apiPwd = tokenInfoBean.getFourInOne().getApiPwd();
                        VolvoImConstant.header_noncestr = UUID.randomUUID().toString();
                    }catch (Exception e){
                    }
                    TUILogin.login(VolvoImConstant.application, loginSdkId, volvoInfo.getData().getCustomerID(), imToken, new TUICallback() {
                        @Override
                        public void onSuccess() {
                            //初始化推送消息
                            OfflineUtil.initVolvoPushParams(volvoInfo);
                            V2TIMSDKConfig logConfig = new V2TIMSDKConfig();
                            logConfig.setLogLevel(VolvoSDKConfig.logLevel);
                            V2TIMManager.getInstance().initSDK(VolvoImConstant.application, SpUtil.getInstance().getInt(VolvoImConstant.SP_SDKAPPID, 0), logConfig);
                            VolvoImCallback.onSuccess(callback);
                        }

                        @Override
                        public void onError(int errorCode, String errorMessage) {
                            VolvoImCallback.onError(callback, errorCode, errorMessage);
                        }
                    });
                } else {
                    VolvoImCallback.onError(callback, volvoInfo.getCode(), volvoInfo.getMsg());
                }
            }

            @Override
            public void error(int errorCode, String errormsg) {
                VolvoImCallback.onError(callback, errorCode, errormsg);
            }
        });
    }

    /**
     * 获取登录用户
     *
     * @return
     */
    public String getUserLogin() {
        return V2TIMManager.getInstance().getLoginUser();
    }

    /**
     * 注册离线消息
     */
    public void registerVolvoImPush(String pushToken) {
        OfflineUtil.registerPush(pushToken);
    }

    public void showLoading(Context mContext) {
        CustomProgressDialog.showLoading(mContext, true);
    }

    public void hideLoading() {
        CustomProgressDialog.stopLoading();
    }

    /**
     * 个人中心进入
     * @param entranceType
     */
    public void openChat(VIMEntranceType entranceType){
        openChat(entranceType,null);
    }

    /**
     * 1、订单详情打开会话页面
     * @param params:  orderType:订单类型
     *                 orderID：订单ID
     *
     * 4、商品详情
     * @param params:product_img:商品图片
     *              product_name：商品名称
     *              product_price:商品价格
     *              v_value：V值
     *              product_spuId：商品ID
     */
    @SuppressLint("NewApi")
    public void openChat(VIMEntranceType entranceType, final Map<String, String> params) {
        //记录会话进入类型
        SpUtil.getInstance().putInt(VolvoImConstant.SP_ENTRANCETYPE, entranceType.getVIMEntranceType());
        //订单进入，记录数据
        if (VIMEntranceType.Order.getVIMEntranceType() == entranceType.getVIMEntranceType() && null != params) {
            String orderType =  params.get("orderType");
            String orderID =  params.get("orderID");
            VolvoImConstant.orderTypeText = orderType;
            VolvoImConstant.orderIdText = orderID;
            if (TextUtils.isEmpty(orderType) || TextUtils.isEmpty(orderID)) {
                return;
            }
        }
        //商品详情进入，记录数据
        if (VIMEntranceType.Product.getVIMEntranceType() == entranceType.getVIMEntranceType() && null != params) {
            //判断数据是否和上次相同
            if(null != params && params.equals(VolvoImConstant.lastTimeMapParams)){
                VolvoImConstant.jumpChatIsOpenDialog = false;
            }else{
                VolvoImConstant.jumpChatIsOpenDialog = true;
            }
            VolvoImConstant.product_img = params.get("product_img");
            VolvoImConstant.product_name =  params.get("product_name");
            VolvoImConstant.product_spuId = params.get("product_spuId");
            VolvoImConstant.product_price = params.get("product_price");
            VolvoImConstant.v_value = params.get("v_value");
        }
        //记录本次进入会话页面数据
        VolvoImConstant.lastTimeMapParams = params;
        //未登录先登录
        if (V2TIMManager.getInstance().getLoginStatus() == V2TIMManager.V2TIM_STATUS_LOGOUT) {
            int loginSdkAppId = SpUtil.getInstance().getInt(VolvoImConstant.SP_SDKAPPID, 0);
            String loginCustomerId = SpUtil.getInstance().getString(VolvoImConstant.SP_CUSTOMERID);
            String loginToken = SpUtil.getInstance().getString(VolvoImConstant.SP_TOKEN);
            TUILogin.login(VolvoImConstant.application, loginSdkAppId, loginCustomerId, loginToken, new TUICallback() {
                @Override
                public void onSuccess() {
                    startOpenChatActivity(SpUtil.getInstance().getString(VolvoImConstant.SP_CUSTOMER_SERVICEID));

                }

                @Override
                public void onError(int errorCode, String errorMessage) {

                }
            });
        } else {
            startOpenChatActivity(SpUtil.getInstance().getString(VolvoImConstant.SP_CUSTOMER_SERVICEID));
        }
    }

    /**
     * 3、推送消息处理
     * 打开会话页面
     */
    public void openChat(VIMEntranceType entranceType, Activity mActivity, String offlineMsgJson) {
        SpUtil.getInstance().putInt(VolvoImConstant.SP_ENTRANCETYPE, entranceType.getVIMEntranceType());
        //订单页面进入
        int currentType = SpUtil.getInstance().getInt(VolvoImConstant.SP_ENTRANCETYPE, 0);
        if (currentType == VIMEntranceType.PushMessageBackground.getVIMEntranceType()) {
            if (V2TIMManager.getInstance().getLoginStatus() == V2TIMManager.V2TIM_STATUS_LOGOUT) {
                int loginSdkAppId = SpUtil.getInstance().getInt(VolvoImConstant.SP_SDKAPPID, 0);
                String loginCustomerId = SpUtil.getInstance().getString(VolvoImConstant.SP_CUSTOMERID);
                String loginToken = SpUtil.getInstance().getString(VolvoImConstant.SP_TOKEN);
                TUILogin.login(VolvoImConstant.application, loginSdkAppId, loginCustomerId, loginToken, new TUICallback() {
                    @Override
                    public void onSuccess() {
                        if (OfflineUtil.isOfflineMsg(offlineMsgJson)) {
                            OfflineMessageBean bean = new Gson().fromJson(offlineMsgJson, OfflineMessageBean.class);
                            handleOfflinePush(mActivity, bean);
                        }
                    }

                    @Override
                    public void onError(int errorCode, String errorMessage) {

                    }
                });
            } else {
                if (OfflineUtil.isOfflineMsg(offlineMsgJson)) {
                    OfflineMessageBean bean = new Gson().fromJson(offlineMsgJson, OfflineMessageBean.class);
                    handleOfflinePush(mActivity, bean);
                }
            }
        }
    }

    /**
     * 设置回调监听
     */
    public void setOnVolvoChatListener(VolvoChatCallback.VolvoChatListener linkClickListener) {
        VolvoChatCallback.volvoChatListener = linkClickListener;
    }

    /**
     * 设置事件统计监听
     */
    public void setOnVolvoEventListener(VolvoChatCallback.VolvoEventListener eventListener) {
        VolvoChatCallback.volvoEventListener = eventListener;
    }

    /**
     * IM登出
     */
    public void logoutIm(final VolvoImCallback callback) {
        SpUtil.getInstance().clear();
        OfflineUtil.unRegisterPush();
        VolvoImConstant.isChatEnd = false;
        VolvoImConstant.isChatStart = false;
        VolvoImConstant.verifyInterceptor = null;
        //登出离线推送
        TUILogin.logout(new TUICallback() {
            @Override
            public void onSuccess() {
                VolvoImCallback.onSuccess(callback);
            }

            @Override
            public void onError(int errorCode, String errorMessage) {
                VolvoImCallback.onError(callback, errorCode, errorMessage);
            }
        });
    }

    /**
     * 得到未读消息数
     *
     * @return
     */
    public void getTotalUnRead(final UnReadMessageListener listener) {
        V2TIMManager.getConversationManager().getTotalUnreadMessageCount(new V2TIMValueCallback<Long>() {
            @Override
            public void onSuccess(Long aLong) {
                listener.unReadTotalMessage(aLong.intValue());
            }

            @Override
            public void onError(int code, String desc) {
                listener.unReadTotalMessage(0);
            }
        });
    }

    /**
     * 未读消息获取更新角标
     * 针对华为手机
     */
    public void registerUnreadListener(){
        V2TIMManager.getConversationManager().addConversationListener(unreadListener);
        V2TIMManager.getConversationManager().getTotalUnreadMessageCount(new V2TIMValueCallback<Long>() {
            @Override
            public void onSuccess(Long aLong) {
                runOnUiThread(() -> unreadListener.onTotalUnreadMessageCountChanged(aLong));
            }

            @Override
            public void onError(int code, String desc) {

            }
        });
    }

    /**
     * 获取用户改变监听
     */
    public void setOnUserStateListener(VolvoChatCallback.UserStateListener stateListener){
        VolvoChatCallback.userStateChangeListener = stateListener;
    }

    /**
     * 取消未读消息监听
     */
    public void removeUnreadListener(){
        V2TIMManager.getConversationManager().removeConversationListener(unreadListener);
    }

    /**
     * 未读消息监听
     */
    V2TIMConversationListener unreadListener = new V2TIMConversationListener() {
        @Override
        public void onTotalUnreadMessageCountChanged(long totalUnreadCount) {
            /**
             *  华为离线推送角标
             */
            OfflineMessageDispatcher.updateBadge(VolvoImConstant.application, (int) totalUnreadCount);
        }
    };

    /**
     * 华为角标推送
     */
    public void offlineMessageHuaweiAngle(Context mContext, int unReadCount) {
        OfflineMessageDispatcher.updateBadge(mContext, unReadCount);
    }

    /**
     * 打开会话页面
     * @param chatId :会话ID
     */
    public void startOpenChatActivity(String chatId) {
        Bundle param = new Bundle();
        param.putInt(TUIConstants.TUIChat.CHAT_TYPE, V2TIMConversation.V2TIM_C2C);
        param.putString(TUIConstants.TUIChat.CHAT_ID, chatId);
        param.putBoolean(TUIConstants.TUIChat.IS_TOP_CHAT, false);
        param.putString(TUIConstants.TUIChat.CHAT_NAME, SpUtil.getInstance().getString(VolvoImConstant.SP_MEMBERNAME));
        TUICore.startActivity(TUIConstants.TUIChat.C2C_CHAT_ACTIVITY_NAME, param);
    }

    /**
     * 解析离线消息,转换为json数据
     *
     * @param offlineIntent
     * @return
     */
    public String parseOfflineMsg(Intent offlineIntent) {
        return new Gson().toJson(OfflineMessageDispatcher.parseOfflineMessage(offlineIntent));
    }

    /**
     * 收到推送消息跳转链接
     *
     * @param mContext
     */
    public void handleOfflinePush(Activity mContext, OfflineMessageBean offlineBean) {

        if (offlineBean != null) {
            mContext.setIntent(null);
            NotificationManager manager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.cancelAll();
            }
            if (offlineBean.action == OfflineMessageBean.REDIRECT_ACTION_CHAT) {
                if (TextUtils.isEmpty(offlineBean.sender)) {
                    return;
                }
                startChat(offlineBean.sender, offlineBean.nickname, offlineBean.chatType);
            }
        }
    }


    /**
     * 3、推送消息
     * 推送消息跳转会话页面
     */
    public void startChat(String chatId, String chatName, int chatType) {
        Bundle bundle = new Bundle();
        bundle.putString(TUIConstants.TUIChat.CHAT_ID, chatId);
        bundle.putString(TUIConstants.TUIChat.CHAT_NAME, chatName);
        bundle.putInt(TUIConstants.TUIChat.CHAT_TYPE, chatType);
        if (chatType == V2TIMConversation.V2TIM_C2C) {
            TUICore.startActivity(TUIConstants.TUIChat.C2C_CHAT_ACTIVITY_NAME, bundle);
        } else if (chatType == V2TIMConversation.V2TIM_GROUP) {
            TUICore.startActivity(TUIConstants.TUIChat.GROUP_CHAT_ACTIVITY_NAME, bundle);
        }
    }

}
