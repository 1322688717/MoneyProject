package com.volvo.tencentim;

public class VolvoSDKConfig {

    /**
     * 应用包名
     */
    public String packaggeName;

    /**
     * 域名设置
     */
    public String doMainUrl;

    /**
     * 日志打印等级
     */
    public static int logLevel;
}
