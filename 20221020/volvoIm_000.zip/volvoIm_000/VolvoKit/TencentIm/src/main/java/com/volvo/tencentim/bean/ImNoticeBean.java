package com.volvo.tencentim.bean;

import java.io.Serializable;

public class ImNoticeBean implements Serializable {

    /**
     * code : 0
     * msg : IM初始化成功！
     * data : {"customerID":"1_4300438","customerServiceID":"exclusive_kf_01","token":"eJwtjc0KgkAURt9ltoZcx*s0CS0aCKPCRTmUqxAc5SLJpBZS9O4N5vL74ZwPy45nn0rTDlSR6VjMghuGABhKtphGM1rqDIulQIB-1VPtjm*OO71tHp5KNtWeFL8m3mU8pDpV*VMv07po*yzHWp1gPbNek4H7MOeB7o4ciEjgKhCAM75sCmupdItTCiEjgO8PZ-cv*w__"}
     */

    private int code;
    private String msg;
    private DataBean data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * customerID : 1_4300438
         * customerServiceID : exclusive_kf_01
         * token : eJwtjc0KgkAURt9ltoZcx*s0CS0aCKPCRTmUqxAc5SLJpBZS9O4N5vL74ZwPy45nn0rTDlSR6VjMghuGABhKtphGM1rqDIulQIB-1VPtjm*OO71tHp5KNtWeFL8m3mU8pDpV*VMv07po*yzHWp1gPbNek4H7MOeB7o4ciEjgKhCAM75sCmupdItTCiEjgO8PZ-cv*w__
         */

        private String customerID;
        private String customerServiceID;
        private String token;

        public String getCustomerID() {
            return customerID;
        }

        public void setCustomerID(String customerID) {
            this.customerID = customerID;
        }

        public String getCustomerServiceID() {
            return customerServiceID;
        }

        public void setCustomerServiceID(String customerServiceID) {
            this.customerServiceID = customerServiceID;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }
    }
}
