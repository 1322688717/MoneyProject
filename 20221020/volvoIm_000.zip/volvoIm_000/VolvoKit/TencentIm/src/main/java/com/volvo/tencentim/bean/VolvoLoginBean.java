package com.volvo.tencentim.bean;

import java.io.Serializable;

/**
 * 登录返回Bean
 */
public class VolvoLoginBean implements Serializable {
    /**
     * success : true
     * data : {"token":"eJyrVgrxCdbLTEnNK8lMy0wtUrJSMow3NVLSAYunVhRkFqUqWVmYmRgYQISKM9OBarIDggyM88MKyrONyl0LzcuiigqToooLLcLLDLLMzLPyAw2Ts3PyHItTC11toWaVgQ030jOA8ksyc4EmG5qZmpuYGBuYGkGNT8lOLCjITAHKAK00M7MwNTCoBQBNpzCx","customerServiceID":"exclusive_kf_01","customerID":"1_52","sdkID":"1400668500","iosPushVO":{"certDev":"33713","certPro":"1111"},"androidPushVO":{"xmCert":"33333","xmAppID":"44444","xmAppKey":"55555","hwCert":"22222","mzCert":"66666","mzAppID":"7777","mzAppKey":"88888","vivoCert":"99999","oppoCert":"121212","oppoAppID":"131313","oppoAppKey":"1414","googleCert":"1020000"}}
     * msg : success
     * errMsg :
     * code : 200
     * internalErrMsg :
     * traceId : 80611270578246b98f2b51c41b4d55e7.74.16574430527910039
     */

    private boolean success;
    private DataBean data;
    private String msg;
    private String errMsg;
    private int code;
    private String internalErrMsg;
    private String traceId;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getInternalErrMsg() {
        return internalErrMsg;
    }

    public void setInternalErrMsg(String internalErrMsg) {
        this.internalErrMsg = internalErrMsg;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public static class DataBean {
        /**
         * token : eJyrVgrxCdbLTEnNK8lMy0wtUrJSMow3NVLSAYunVhRkFqUqWVmYmRgYQISKM9OBarIDggyM88MKyrONyl0LzcuiigqToooLLcLLDLLMzLPyAw2Ts3PyHItTC11toWaVgQ030jOA8ksyc4EmG5qZmpuYGBuYGkGNT8lOLCjITAHKAK00M7MwNTCoBQBNpzCx
         * customerServiceID : exclusive_kf_01
         * customerID : 1_52
         * sdkID : 1400668500
         * iosPushVO : {"certDev":"33713","certPro":"1111"}
         * androidPushVO : {"xmCert":"33333","xmAppID":"44444","xmAppKey":"55555","hwCert":"22222","mzCert":"66666","mzAppID":"7777","mzAppKey":"88888","vivoCert":"99999","oppoCert":"121212","oppoAppID":"131313","oppoAppKey":"1414","googleCert":"1020000"}
         */

        private String token;
        private String customerServiceID;
        private String customerID;
        private String sdkID;
        private IosPushVOBean iosPushVO;
        private AndroidPushVOBean androidPushVO;

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public String getCustomerServiceID() {
            return customerServiceID;
        }

        public void setCustomerServiceID(String customerServiceID) {
            this.customerServiceID = customerServiceID;
        }

        public String getCustomerID() {
            return customerID;
        }

        public void setCustomerID(String customerID) {
            this.customerID = customerID;
        }

        public String getSdkID() {
            return sdkID;
        }

        public void setSdkID(String sdkID) {
            this.sdkID = sdkID;
        }

        public IosPushVOBean getIosPushVO() {
            return iosPushVO;
        }

        public void setIosPushVO(IosPushVOBean iosPushVO) {
            this.iosPushVO = iosPushVO;
        }

        public AndroidPushVOBean getAndroidPushVO() {
            return androidPushVO;
        }

        public void setAndroidPushVO(AndroidPushVOBean androidPushVO) {
            this.androidPushVO = androidPushVO;
        }

        public static class IosPushVOBean {
            /**
             * certDev : 33713
             * certPro : 1111
             */

            private String certDev;
            private String certPro;

            public String getCertDev() {
                return certDev;
            }

            public void setCertDev(String certDev) {
                this.certDev = certDev;
            }

            public String getCertPro() {
                return certPro;
            }

            public void setCertPro(String certPro) {
                this.certPro = certPro;
            }
        }

        public static class AndroidPushVOBean {
            /**
             * xmCert : 33333
             * xmAppID : 44444
             * xmAppKey : 55555
             * hwCert : 22222
             * mzCert : 66666
             * mzAppID : 7777
             * mzAppKey : 88888
             * vivoCert : 99999
             * oppoCert : 121212
             * oppoAppID : 131313
             * oppoAppKey : 1414
             * googleCert : 1020000
             */

            private String xmCert;
            private String xmAppID;
            private String xmAppKey;
            private String hwCert;
            private String mzCert;
            private String mzAppID;
            private String mzAppKey;
            private String vivoCert;
            private String oppoCert;
            private String oppoAppID;
            private String oppoAppKey;
            private String googleCert;

            public String getXmCert() {
                return xmCert;
            }

            public void setXmCert(String xmCert) {
                this.xmCert = xmCert;
            }

            public String getXmAppID() {
                return xmAppID;
            }

            public void setXmAppID(String xmAppID) {
                this.xmAppID = xmAppID;
            }

            public String getXmAppKey() {
                return xmAppKey;
            }

            public void setXmAppKey(String xmAppKey) {
                this.xmAppKey = xmAppKey;
            }

            public String getHwCert() {
                return hwCert;
            }

            public void setHwCert(String hwCert) {
                this.hwCert = hwCert;
            }

            public String getMzCert() {
                return mzCert;
            }

            public void setMzCert(String mzCert) {
                this.mzCert = mzCert;
            }

            public String getMzAppID() {
                return mzAppID;
            }

            public void setMzAppID(String mzAppID) {
                this.mzAppID = mzAppID;
            }

            public String getMzAppKey() {
                return mzAppKey;
            }

            public void setMzAppKey(String mzAppKey) {
                this.mzAppKey = mzAppKey;
            }

            public String getVivoCert() {
                return vivoCert;
            }

            public void setVivoCert(String vivoCert) {
                this.vivoCert = vivoCert;
            }

            public String getOppoCert() {
                return oppoCert;
            }

            public void setOppoCert(String oppoCert) {
                this.oppoCert = oppoCert;
            }

            public String getOppoAppID() {
                return oppoAppID;
            }

            public void setOppoAppID(String oppoAppID) {
                this.oppoAppID = oppoAppID;
            }

            public String getOppoAppKey() {
                return oppoAppKey;
            }

            public void setOppoAppKey(String oppoAppKey) {
                this.oppoAppKey = oppoAppKey;
            }

            public String getGoogleCert() {
                return googleCert;
            }

            public void setGoogleCert(String googleCert) {
                this.googleCert = googleCert;
            }
        }
    }
}
