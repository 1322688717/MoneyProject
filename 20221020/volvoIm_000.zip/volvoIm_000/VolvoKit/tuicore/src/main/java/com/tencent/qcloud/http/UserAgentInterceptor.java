package com.tencent.qcloud.http;

import android.content.Context;
import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class UserAgentInterceptor implements Interceptor {
    private Context mContext;

    public UserAgentInterceptor(Context context) {
        this.mContext = context;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
        Request.Builder builder = request.newBuilder();
        builder.addHeader("device-info", "");
        builder.addHeader("i-request-point", "app");
        request = builder.build();
        return chain.proceed(request);
    }


}
