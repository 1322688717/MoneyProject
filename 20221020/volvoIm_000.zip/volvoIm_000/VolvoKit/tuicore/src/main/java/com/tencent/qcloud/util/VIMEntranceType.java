package com.tencent.qcloud.util;

public enum VIMEntranceType {
    /**
     * 1、订单详情进入
     */
    Order(1),
    /**
     * 2、个人中心进入
     */
    PersonalCenter(2),
    /**
     * 3、后台推送消息进入
     */
    PushMessageBackground(3),
    /**
     * 4、商品详情进入
     */
    Product(4);

    private int entranceType;

    public int getVIMEntranceType() {
        return entranceType;
    }

    VIMEntranceType(int brandCode) {
        this.entranceType = brandCode;
    }
}
