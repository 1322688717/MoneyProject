package com.tencent.qcloud.http;

import java.util.Map;

/**
 * Author by SPRING,
 * Date on 2019/7/18.
 * PS: Not easy to write code, please indicate.
 */
public interface FactoryIn {

    /**
     *
     * @param url      请求url
     * @param params  参数
     * @param isList     data是否是集合  0对象  1集合
     * @param callBack   请求回调
     */
    void doPost(String url, Map<String, Object> params, int isList, NetworkCallback callBack);

}
