package com.tencent.qcloud.http;


import android.text.TextUtils;

import com.tencent.qcloud.util.SpUtil;
import com.tencent.qcloud.util.VolvoImConstant;

import java.util.Map;

public class MposRequest {

    private static MposRequest mposRequest;

    /**
     * 获取用户控制类单例对象
     */
    public static MposRequest getInstance() {

        if (mposRequest == null) {
            synchronized (MposRequest.class) {
                if (mposRequest == null) {
                    mposRequest = new MposRequest();
                }
            }
        }
        return mposRequest;
    }

    //查询IM信息
    public void getDemoLoginInfo(Map<String,Object> paramsMap,int noticeType,NetworkCallback callback){
        paramsMap.put("noticeType",noticeType);
        paramsMap.put("source", 1);
        OkHttpModel.getInstance().doPost(SpUtil.getInstance().getString(VolvoImConstant.SP_DOMAINURL) + Urls.NOTICEINFO, paramsMap,0, callback);
    }

    //查询登录信息，bff调用
    public void getVolvoLoginInfo(Map<String,Object> paramsMap,int noticeType,NetworkCallback callback){
        paramsMap.put("noticeType",noticeType);
        paramsMap.put("source", 1);
        OkHttpModel.getInstance().doPost(SpUtil.getInstance().getString(VolvoImConstant.SP_DOMAINURL)+ Urls.VOLVOLOGINURL,paramsMap,0,callback);
    }

    //满意度提交接口查询
    public void httpSubmitSaticfaction(Map<String,Object> params,NetworkCallback callback){
        String httpRequestUrl = VolvoImConstant.token_satisfactionBaseUrl+ VolvoImConstant.token_satisfactionApiUrl;
        if(TextUtils.isEmpty(httpRequestUrl) && null != callback){
            callback.error(99,"requestUrl is null");
        }
        OkHttpModel.getInstance().doPost(httpRequestUrl,params,0,callback);
    }

}
