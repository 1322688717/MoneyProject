package com.tencent.qcloud.util;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

public class VolvoChatCallback {

    public static VolvoChatListener volvoChatListener;
    public static VolvoEventListener volvoEventListener;
    public static UserStateListener userStateChangeListener;

    /**
     * 会话页面点击
     */
    public interface VolvoChatListener{
        //欢迎消息链接
        void onLinkClick(AppCompatActivity mContext, String linkContent);
        //客服电话
        void onCustomerClick(AppCompatActivity mContext);
        //会话开始
        void onConversationStart();
        //会话结束
        void onConversationEnd();
        //商品详情
        void onProductClick(AppCompatActivity mContext,String productspuId);
    }

    /**
     * 事件统计
     */
    public interface VolvoEventListener{
        void trackEventWithProperties(String event, JSONObject propertieDict);
    }

    /**
     * 用户状态变更
     */
    public interface UserStateListener{
        //连接失败,错误信息
        void onConnectFailed(int errorCode,String errorMsg);
        //token过期
        void onUserSigExpired();
    }
}
