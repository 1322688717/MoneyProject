package com.tencent.qcloud.http;



/**
 * Author by SPRING,
 * Date on 2019/1/4.
 * PS: Not easy to write code, please indicate.
 */
public interface NetworkCallback {
    void success(String result);
    void error(int errorCode, String errormsg);
}
