package com.tencent.qcloud.util;

import android.os.Handler;
import android.os.Looper;

/**
 * Author by SPRING,
 * Date on 2019/1/4.
 * PS: Not easy to write code, please indicate.
 */
public class Runableutils {
    private static Handler shandler=new Handler(Looper.getMainLooper());
    public static void mainthread(Runnable myrun){
        shandler.post(myrun);
    }
}
