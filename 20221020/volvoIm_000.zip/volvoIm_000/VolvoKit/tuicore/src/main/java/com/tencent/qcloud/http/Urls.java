package com.tencent.qcloud.http;

public class Urls {

    //IM信息请求
    public static final String NOTICEINFO = "im/v1/notice";

    //======================================================================================================
    //IM信息请求
    public static final String VOLVOLOGINURL ="app/im/api/v1/notice";


}
