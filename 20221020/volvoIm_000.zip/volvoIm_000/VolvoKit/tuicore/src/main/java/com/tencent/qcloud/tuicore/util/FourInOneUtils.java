package com.tencent.qcloud.tuicore.util;


import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.TreeMap;

/**
 * Author: wangchuan
 * Date: 2022/6/13 下午4:23
 **/

public class FourInOneUtils {

    public static String getCheckSign(String pathUrl, String clientId, String clientPwd, String noncestr, String timestamp)
    {
        pathUrl = pathUrl.toLowerCase();
        TreeMap<String, String> sortedParameters =
                new TreeMap<String, String>();
        sortedParameters.put("apipwd",clientPwd);
        sortedParameters.put("apiuid",clientId);
        sortedParameters.put("noncestr",noncestr);
        sortedParameters.put("timestamp",timestamp);
        // 字串拼接
        StringBuilder sbSignContent = new StringBuilder();
        sbSignContent.append(pathUrl);
        for(String key : sortedParameters.keySet())
        {
            sbSignContent.append(key + "=" + sortedParameters.get(key));
        }

        return FourInOneUtils.getMd5(sbSignContent.toString());
    }

    public static String getMd5(String plainText)
    {
        byte[] secretBytes = null;
        try {
            secretBytes = MessageDigest.getInstance("md5").digest(
                    plainText.getBytes());
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("没有md5这个算法！");
        }
        String md5code = new BigInteger(1, secretBytes).toString(16);// 16进制数字
        // 如果生成数字未满32位，需要前面补0
        for (int i = 0; i < 32 - md5code.length(); i++) {
            md5code = "0" + md5code;
        }
        return md5code.replace("-", "");
    }

}
