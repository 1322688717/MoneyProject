package com.tencent.qcloud.tuicore.util;

import androidx.core.content.FileProvider;

public class TUIFileProvider extends FileProvider {
}
