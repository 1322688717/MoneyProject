package com.tencent.qcloud.http;

import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.tencent.qcloud.tuicore.util.FileUtil;
import com.tencent.qcloud.tuicore.util.FourInOneUtils;
import com.tencent.qcloud.tuicore.util.MD5Utils;
import com.tencent.qcloud.tuicore.util.ToastUtil;
import com.tencent.qcloud.util.Runableutils;
import com.tencent.qcloud.util.SpUtil;
import com.tencent.qcloud.util.VolvoImConstant;

import java.io.IOException;
import java.net.Proxy;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class OkHttpModel implements FactoryIn {
    private OkHttpClient.Builder client;
    private static OkHttpModel okHttpModel = null;
    private String NONETWORK = "无可用网络！请检查网络";
    private String ERRORPLEASEAGAIN = "获取数据失败！";

    public OkHttpModel() {
        this.init();
    }

    public static OkHttpModel getInstance() {
        if (okHttpModel == null) {
            synchronized (OkHttpModel.class) {
                okHttpModel = new OkHttpModel();
            }
        }
        return okHttpModel;
    }

    private void init() {
        client = new OkHttpClient.Builder();
        if (null != VolvoImConstant.verifyInterceptor) {
            client.addInterceptor(VolvoImConstant.verifyInterceptor);
        }
//        client.addNetworkInterceptor(logInterceptor);
//        logInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        client.connectTimeout(10, TimeUnit.SECONDS);
        client.readTimeout(10, TimeUnit.SECONDS);
        client.writeTimeout(10, TimeUnit.SECONDS);
        client.retryOnConnectionFailure(true);
        client.proxy(Proxy.NO_PROXY);

    }

    @Override
    public void doPost(String url, Map<String, Object> params, final int isList, final NetworkCallback callBack) {
        try {

            RequestBody body = FormBody.create(MediaType.parse("application/json"), new Gson().toJson(params));
            Request request;
            String timeStamp = MD5Utils.getTimestamp();
            if (SpUtil.getInstance().getBoolean(VolvoImConstant.SP_ISDEMOTEST, false)) {
                request = new Request.Builder()
                        .url(url)
                        //新增header信息
                        .addHeader("apiuid", VolvoImConstant.header_apiuid)
                        .addHeader("noncestr", VolvoImConstant.header_noncestr)
                        .addHeader("timestamp", timeStamp)
                        .addHeader("sign", FourInOneUtils.getCheckSign(VolvoImConstant.token_satisfactionApiUrl,VolvoImConstant.header_apiuid,VolvoImConstant.token_apiPwd,VolvoImConstant.header_noncestr,timeStamp))
                        .post(body)
                        .build();
            } else {
                request = new Request.Builder()
                        .url(url)
                        .addHeader("Authorization", VolvoImConstant.header_Authorization)
                        .addHeader("X-Token", VolvoImConstant.header_X_Token)
                        //新增的header信息
                        .addHeader("apiuid", VolvoImConstant.header_apiuid)
                        .addHeader("noncestr", VolvoImConstant.header_noncestr)
                        .addHeader("timestamp", timeStamp)
                        .addHeader("sign", FourInOneUtils.getCheckSign(VolvoImConstant.token_satisfactionApiUrl,VolvoImConstant.header_apiuid,VolvoImConstant.token_apiPwd,VolvoImConstant.header_noncestr,timeStamp))
                        .post(body)
                        .build();
            }
            client.build().newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, final IOException e) {
                    Runableutils.mainthread(new Runnable() {
                        @Override
                        public void run() {
                            if (null != callBack) {
                                callBack.error(3, e.getMessage());
                            }

                        }
                    });
                }

                @Override
                public void onResponse(Call call, final Response response) throws IOException {

                    final String result = response.body().string();
                    if (!TextUtils.isEmpty(result)) {
                        try {
                            Runableutils.mainthread(new Runnable() {
                                @Override
                                public void run() {
                                    if (null != callBack) {
                                        callBack.success(result);
                                    }

                                }
                            });
                        } catch (Exception e) {
                            e.printStackTrace();
                            Runableutils.mainthread(new Runnable() {
                                @Override
                                public void run() {
                                    if (null != callBack) {
                                        callBack.error(1, "数据接收异常");
                                    }

                                }
                            });
                        }
                    } else {
                        Runableutils.mainthread(new Runnable() {
                            @Override
                            public void run() {
                                if (null != callBack) {
                                    callBack.error(2, "系统错误");
                                }
                            }
                        });
                    }
                }
            });
        } catch (Exception e) {
            showMessage(ERRORPLEASEAGAIN);
        }
    }


    //    展示网络请求的不正常返回结果
    public void showMessage(final String message) {
        Runableutils.mainthread(new Runnable() {
            @Override
            public void run() {
                ToastUtil.toastShortMessage(message);

            }
        });
    }

}
