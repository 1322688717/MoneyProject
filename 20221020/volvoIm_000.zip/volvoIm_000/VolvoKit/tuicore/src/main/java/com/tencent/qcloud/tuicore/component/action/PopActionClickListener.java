package com.tencent.qcloud.tuicore.component.action;


public interface PopActionClickListener {
    void onActionClick(int index, Object data);
}
