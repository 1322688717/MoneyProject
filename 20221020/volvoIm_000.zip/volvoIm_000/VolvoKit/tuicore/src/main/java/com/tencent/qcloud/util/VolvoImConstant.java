package com.tencent.qcloud.util;


import android.app.Application;

import java.util.Map;

import okhttp3.Interceptor;

/**
 *
 */
public class VolvoImConstant {

    public static Application application;
    //列表请求头信息记录
    public static String header_Authorization = "";
    public static String header_X_Token = "";
    //满意度提交信息
    public static String header_apiuid = "";
    //随机字符串（UUID值）
    public static String header_noncestr = "";
    //满意度baseUrl地址
    public static String token_satisfactionBaseUrl = "";
    //满意度接口地址
    public static String token_satisfactionApiUrl = "";
    //登录返回
    public static String token_apiPwd = "";
    //记录进入会话页面的事件，方便统计时长
    public static long buriedStartTime;
    //记录上次进会话页面的数据
    public static Map<String,String> lastTimeMapParams;
    //进入会话页面 商品信息 是否和上次一样的信息，是否进行弹窗
    public static boolean jumpChatIsOpenDialog;


    //外部数据传递
    public static String VOLVO_MEMBERID = "memberID";
    public  static String VOLVO_MEMBERNAME = "memberName";
    public  static String VOLVO_MEMBERURL = "memberUrl";
    //拦截器记录
    public static Interceptor verifyInterceptor;

    //记录订单类型、订单号
    public static String orderTypeText = "";
    public static String orderIdText = "";
    //记录会话开始、结束时间标识
    public static boolean isChatStart = false;
    public static boolean isChatEnd = false;

    //商品详情记录
    public static String product_img;
    public static String product_name;
    public static String product_price;
    public static String v_value;
    public static String product_spuId;

    //===========================  SharedPreferences Key值标记 ========================================
    public final static String SP_CUSTOMERID = "sp_customerId";
    public final static String SP_TOKEN = "sp_token";
    public final static String SP_CUSTOMER_SERVICEID = "sp_customer_serviceId";
    public final static String SP_MEMBERID = "sp_memberId";
    public final static String SP_MEMBERNAME = "sp_membername";
    public final static String SP_MEMBERURL = "sp_memberUrl";
    public final static String SP_SDKAPPID = "sp_sdkAppId";
    //是否为demo测试
    public final static String SP_ISDEMOTEST = "sp_isDemo";
    //外部App标识
    public final static String SP_APPREMARK = "sp_appRemark";
    //入口来源标识
    public final static String SP_ENTRANCETYPE = "sp_entranceType";
    //域名标识
    public final static String SP_DOMAINURL = "sp_domainUrl";

}
