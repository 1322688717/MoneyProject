package com.tencent.qcloud.tuikit.tuichat.bean.message;

import java.io.Serializable;

public class CustomLinkBean implements Serializable {

    /**
     * name : 了解车型
     * id : LearnAboutCars
     * param : {"car_num":"123"}
     */

    private String name;
    private String id;
    private ParamBean param;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ParamBean getParam() {
        return param;
    }

    public void setParam(ParamBean param) {
        this.param = param;
    }

    public static class ParamBean {
        /**
         * car_num : 123
         */

        private String car_num;

        public String getCar_num() {
            return car_num;
        }

        public void setCar_num(String car_num) {
            this.car_num = car_num;
        }
    }
}
