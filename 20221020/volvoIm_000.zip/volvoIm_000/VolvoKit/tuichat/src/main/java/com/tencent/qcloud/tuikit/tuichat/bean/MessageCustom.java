package com.tencent.qcloud.tuikit.tuichat.bean;

public class MessageCustom {
    public static final String BUSINESS_ID_GROUP_CREATE = "group_create";

    public int version = 0;
    public String businessID;
    public String opUser;
    public String content;
    public String data;
}
