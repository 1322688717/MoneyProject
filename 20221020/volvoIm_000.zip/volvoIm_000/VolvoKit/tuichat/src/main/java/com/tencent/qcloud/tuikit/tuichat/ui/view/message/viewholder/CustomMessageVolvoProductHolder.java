package com.tencent.qcloud.tuikit.tuichat.ui.view.message.viewholder;

import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.tencent.qcloud.tuicore.component.imageEngine.impl.GlideEngine;
import com.tencent.qcloud.tuikit.tuichat.R;
import com.tencent.qcloud.tuikit.tuichat.bean.CustomMessageVolvoProductMessage;
import com.tencent.qcloud.tuikit.tuichat.bean.message.CustomMessageVolvoProductBean;
import com.tencent.qcloud.tuikit.tuichat.bean.message.TUIMessageBean;
import com.tencent.qcloud.tuikit.tuichat.util.TUIChatUtils;
import com.tencent.qcloud.util.VolvoChatCallback;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * 自定义消息
 * 商品列表
 */
public class CustomMessageVolvoProductHolder extends MessageContentHolder {

    private ImageView img_volvoPproduct;
    private TextView tv_product_name,tv_productPrice;
    private RelativeLayout layout_volvo_product;

    private CustomMessageVolvoProductMessage productInfo;

    public CustomMessageVolvoProductHolder(View itemView) {
        super(itemView);
        img_volvoPproduct = itemView.findViewById(R.id.img_volvoPproduct);
        tv_product_name = itemView.findViewById(R.id.tv_product_name);
        tv_productPrice = itemView.findViewById(R.id.tv_productPrice);
        layout_volvo_product = itemView.findViewById(R.id.layout_volvo_product);
    }

    public static final String TAG = CustomMessageVolvoProductHolder.class.getSimpleName();

    @Override
    public int getVariableLayout() {
        return R.layout.test_custom_message_volvo_product;
    }

    @Override
    public void layoutVariableViews(TUIMessageBean msg, int position) {
        // 自定义消息view的实现，这里仅仅展示文本信息，并且实现超链接跳转
        String text = "";
        if (msg instanceof CustomMessageVolvoProductBean) {
            text = msg.getExtra();
        }
        if(TUIChatUtils.isContentJson(text)){
            productInfo = new Gson().fromJson(text, CustomMessageVolvoProductMessage.class);
            if(null != productInfo){
                //图片加载
                if(null != productInfo && null != productInfo.getProduct_info()){
                    GlideEngine.loadCornerImageWithoutPlaceHolder(img_volvoPproduct, productInfo.getProduct_info().getProduct_img(), null, 5);
                    tv_product_name.setText(productInfo.getProduct_info().getProduct_name());
                    tv_productPrice.setText(Html.fromHtml("¥")+ productInfo.getProduct_info().getProduct_price()+" （"+productInfo.getProduct_info().getV_value()+" V值）");
                }
               }
        }
        layout_volvo_product.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(null == productInfo || null == productInfo.getProduct_info()){
                    return;
                }
                //点击回调
                if (null != VolvoChatCallback.volvoChatListener && itemView.getContext() instanceof AppCompatActivity) {
                    if (null != productInfo.getProduct_info().getSpuId()) {
                        VolvoChatCallback.volvoChatListener.onProductClick((AppCompatActivity) itemView.getContext(), productInfo.getProduct_info().getSpuId());
                    }
                }
                //埋点回调
                if (null != VolvoChatCallback.volvoEventListener) {
                    try {
                        Map<String, String> buriedPoint = new HashMap<>();
                        buriedPoint.put("page_title", "在线客服");
                        buriedPoint.put("btn_type", "btn");
                        buriedPoint.put("btn_name", "商品信息卡片");
                        JSONObject jsonData = new JSONObject(buriedPoint.toString());
                        VolvoChatCallback.volvoEventListener.trackEventWithProperties("Button_click", jsonData);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

}
