package com.tencent.qcloud.tuikit.tuichat.bean.message;

import com.google.gson.Gson;
import com.tencent.imsdk.v2.V2TIMMessage;
import com.tencent.qcloud.tuikit.tuichat.R;
import com.tencent.qcloud.tuikit.tuichat.TUIChatService;
import com.tencent.qcloud.tuikit.tuichat.bean.CustomHelloVolvoMessage;
import com.tencent.qcloud.tuikit.tuichat.bean.CustomVolvoSatisfactionMessage;
import com.tencent.qcloud.tuikit.tuichat.bean.message.reply.CustomLinkReplyQuoteBean;
import com.tencent.qcloud.tuikit.tuichat.bean.message.reply.TUIReplyQuoteBean;

/**
 * 自定义  满意度调查
 */
public class CustomMessageVolvoSatisfactionBean extends TUIMessageBean {

    private CustomVolvoSatisfactionMessage customHelloVolvoMessage;

    @Override
    public String onGetDisplayString() {
        return getText();
    }

    @Override
    public void onProcessMessage(V2TIMMessage v2TIMMessage) {
//        String data = new String(v2TIMMessage.getCustomElem().getData());
        String data = v2TIMMessage.getCustomElem().getDescription();
        try {
            customHelloVolvoMessage = new Gson().fromJson(data, CustomVolvoSatisfactionMessage.class);
            if (customHelloVolvoMessage != null) {
                setExtra(data);
            } else {
                String text = TUIChatService.getAppContext().getString(R.string.no_support_msg);
                setExtra(text);
            }
        }catch (Exception e){
            String text = TUIChatService.getAppContext().getString(R.string.no_support_msg);
            setExtra(text);
        }

    }

    public String getText() {
        return getExtra();
    }

    @Override
    public Class<? extends TUIReplyQuoteBean> getReplyQuoteBeanClass() {
        return CustomLinkReplyQuoteBean.class;
    }
}
