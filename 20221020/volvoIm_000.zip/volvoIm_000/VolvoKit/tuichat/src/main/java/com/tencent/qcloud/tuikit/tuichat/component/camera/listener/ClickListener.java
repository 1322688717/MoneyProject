package com.tencent.qcloud.tuikit.tuichat.component.camera.listener;


public interface ClickListener {
    void onClick();
}
