package com.tencent.qcloud.tuikit.tuichat.ui.view.dialog;

import android.app.Dialog;
import android.content.Context;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.tencent.qcloud.tuicore.component.imageEngine.impl.GlideEngine;
import com.tencent.qcloud.tuikit.tuichat.R;
import com.tencent.qcloud.tuikit.tuichat.bean.CustomMessageVolvoProductMessage;
import com.tencent.qcloud.tuikit.tuichat.ui.view.message.SelectTextHelper;
import com.tencent.qcloud.util.VolvoImConstant;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 * 商品详情订单
 */
public class ProductBottomDialog extends Dialog implements View.OnClickListener {

    private Context mContext;
    private View rootView;
    private ImageView img_product;
    private TextView tv_product_name,tv_productPrice,volvo_productCancel,volvo_productConfirm;
    private onProduceSelectListener produceSelectListener;

    public void setOnProductSelectListener(onProduceSelectListener listener){
        this.produceSelectListener = listener;
    }

    public ProductBottomDialog(@NonNull Context context) {
        super(context, R.style.transDialog);
        mContext = context;
        getWindow().setWindowAnimations(R.style.public_dialog_bottom_anim);
        rootView = LayoutInflater.from(mContext).inflate(R.layout.dialog_product_info,null);
        setContentView(rootView);
        initView();

        setDialogLocation();
    }

    private void initView(){
        img_product = rootView.findViewById(R.id.img_product);
        tv_product_name = rootView.findViewById(R.id.tv_product_name);
        tv_productPrice = rootView.findViewById(R.id.tv_productPrice);
        volvo_productCancel = rootView.findViewById(R.id.volvo_productCancel);
        volvo_productConfirm = rootView.findViewById(R.id.volvo_productConfirm);
        volvo_productCancel.setOnClickListener(this);
        volvo_productConfirm.setOnClickListener(this);
        tv_product_name.setText(VolvoImConstant.product_name);
        tv_productPrice.setText(Html.fromHtml("¥")+VolvoImConstant.product_price+" （"+VolvoImConstant.v_value+" V值）");
        //图片加载
        GlideEngine.loadCornerImageWithoutPlaceHolder(img_product, VolvoImConstant.product_img, null, 10);

    }

    private void setDialogLocation(){
        setCanceledOnTouchOutside(false);
        getWindow().setGravity(Gravity.BOTTOM);
        WindowManager.LayoutParams params = getWindow().getAttributes();
        //距离底部的问题，输入框高度+10
        params.y = SelectTextHelper.dp2px(65);
        params.width = mContext.getResources().getDisplayMetrics().widthPixels - SelectTextHelper.dp2px(20);
        params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        getWindow().setAttributes(params);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.volvo_productCancel){
            if(null != produceSelectListener){
                produceSelectListener.onCancel();
            }
            dismiss();
        }else if(view.getId() == R.id.volvo_productConfirm){
            CustomMessageVolvoProductMessage productInfoMessage = new CustomMessageVolvoProductMessage();
            productInfoMessage.setBusinessID("product_msg");
            CustomMessageVolvoProductMessage.ProductInfoBean bean = new CustomMessageVolvoProductMessage.ProductInfoBean();
            bean.setProduct_name(VolvoImConstant.product_name);
            bean.setSpuId(VolvoImConstant.product_spuId);
            bean.setProduct_img(VolvoImConstant.product_img);
            bean.setProduct_price(VolvoImConstant.product_price);
            bean.setV_value(VolvoImConstant.v_value);
            productInfoMessage.setProduct_info(bean);

            if(null != produceSelectListener){
                produceSelectListener.onConfirm(productInfoMessage);
            }
            dismiss();
        }
    }

    public interface onProduceSelectListener{
        void onCancel();
        void onConfirm(CustomMessageVolvoProductMessage productbean);
    }
}
