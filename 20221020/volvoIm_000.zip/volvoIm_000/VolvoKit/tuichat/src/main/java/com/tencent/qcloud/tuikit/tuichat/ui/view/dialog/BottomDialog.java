package com.tencent.qcloud.tuikit.tuichat.ui.view.dialog;


import android.app.Dialog;
import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.tencent.qcloud.tuikit.tuichat.R;

/**
 * 订单信息 底部弹窗
 */
public class BottomDialog extends Dialog implements View.OnClickListener {

    private View mRoot;
    private Context mContext;
    private TextView volvo_orderCancel,volvo_orderConfirm,volvo_orderInfo;

    private OnOrderSelectListener orderSelectListener;

    public BottomDialog(Context context,String typeShow,String orderId) {
        super(context, R.style.public_dialog_bottom);
        getWindow().setWindowAnimations(R.style.public_dialog_bottom_anim);
        mContext = context;
        mRoot = LayoutInflater.from(context).inflate(R.layout.dialog_order_info, null);
        volvo_orderCancel = mRoot.findViewById(R.id.volvo_orderCancel);
        volvo_orderConfirm = mRoot.findViewById(R.id.volvo_orderConfirm);
        volvo_orderCancel.setOnClickListener(this);
        volvo_orderConfirm.setOnClickListener(this);
        volvo_orderInfo = mRoot.findViewById(R.id.volvo_orderInfo);
        volvo_orderInfo.setText("("+typeShow+")  订单编号："+orderId);
        setContentView(mRoot);
    }

    //设置监听
    public void setOnOrderSelectListener(OnOrderSelectListener listener){
        this.orderSelectListener = listener;
    }

    @Override
    public void show() {
        if (isShowing()){
            return;
        }
        super.show();
        Window window = getWindow();
        if (window == null) {
            return;
        }
        WindowManager.LayoutParams layoutParams = window.getAttributes();
        layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
        layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        layoutParams.gravity = Gravity.CENTER | Gravity.BOTTOM;
        View decorView = window.getDecorView();
        decorView.setPadding(0, 0, 0, 0);
        window.setAttributes(layoutParams);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.volvo_orderCancel){
            if(null != orderSelectListener){
                orderSelectListener.onCancel();
            }
        }else if(view.getId() == R.id.volvo_orderConfirm){
            if(null != orderSelectListener){
                orderSelectListener.onConfirm();
            }
        }
    }

    public interface OnOrderSelectListener{
        void onCancel();
        void onConfirm();
    }

}
