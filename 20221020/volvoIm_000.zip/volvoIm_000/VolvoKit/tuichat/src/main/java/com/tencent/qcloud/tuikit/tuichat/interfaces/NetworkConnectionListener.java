package com.tencent.qcloud.tuikit.tuichat.interfaces;

public interface NetworkConnectionListener {
    void onConnected();
}
