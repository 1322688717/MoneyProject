package com.tencent.qcloud.tuikit.tuichat.ui.view.message;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import com.tencent.qcloud.tuicore.util.ToastUtil;
import com.tencent.qcloud.tuikit.tuichat.R;
import com.tencent.qcloud.tuikit.tuichat.bean.CustomVolvoSatisfactionMessage;

import java.util.List;

/**
 * 问题布局适配器
 */
public class SatisfactionQuesionAdapter extends BaseAdapter {

    private Context mContext;
    private List<CustomVolvoSatisfactionMessage.QuesionsBean.AnswersBean> answerList;
    private boolean isCanClickAble;

    public SatisfactionQuesionAdapter(Context mContext,List<CustomVolvoSatisfactionMessage.QuesionsBean.AnswersBean> answers,boolean canClickAble) {
        this.mContext = mContext;
        this.answerList = answers;
        this.isCanClickAble = canClickAble;
    }

    @Override
    public int getCount() {
        return null == answerList ? 0 : answerList.size();
    }

    @Override
    public Object getItem(int i) {
        return answerList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        SatisFactionViewHolder viewHolder = null;
        if(null == view){
            viewHolder = new SatisFactionViewHolder();
            view = LayoutInflater.from(mContext).inflate(R.layout.volvo_satisfaction_item_quesion,null);
            viewHolder.volvo_item_checkShow = view.findViewById(R.id.volvo_item_checkShow);
            view.setTag(viewHolder);
        }else{
            viewHolder = (SatisFactionViewHolder) view.getTag();
        }
        if(isCanClickAble){
            viewHolder.volvo_item_checkShow.setButtonDrawable(R.drawable.volvo_satisfaction_radio_selector);
            viewHolder.volvo_item_checkShow.setEnabled(true);
        }else{
            viewHolder.volvo_item_checkShow.setButtonDrawable(R.drawable.volvo_satisfaction_radio_isselectored);
            viewHolder.volvo_item_checkShow.setEnabled(false);
        }
        viewHolder.volvo_item_checkShow.setText(answerList.get(i).getAnswer_content());
        if(0 == answerList.get(i).getSelect()){
            viewHolder.volvo_item_checkShow.setChecked(false);
        }else{
            viewHolder.volvo_item_checkShow.setChecked(true);
        }
        SatisFactionViewHolder finalViewHolder = viewHolder;
        viewHolder.volvo_item_checkShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(finalViewHolder.volvo_item_checkShow.isChecked()){
                    for(int d=0;d<answerList.size();d++){
                        if(i == d){
                            answerList.get(d).setSelect(1);
                        }else{
                            answerList.get(d).setSelect(0);
                        }
                    }
                    notifyDataSetChanged();
                }else{
                    boolean isCanCancel = false;
                    for(int d=0;d<answerList.size();d++){
                        if(i != d && answerList.get(d).getSelect() == 1){
                            answerList.get(d).setSelect(1);
                            isCanCancel = true;
                            break;
                        }else {
                            answerList.get(d).setSelect(0);
                        }
                    }
                    if(!isCanCancel){
                        finalViewHolder.volvo_item_checkShow.setChecked(true);
                    }
                }
            }
        });
        return view;
    }

    class SatisFactionViewHolder {
        CheckBox volvo_item_checkShow;

    }
}
