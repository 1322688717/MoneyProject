package com.tencent.qcloud.tuikit.tuichat.component.camera.listener;

public interface ErrorListener {

    void onError();

    void AudioPermissionError();
}
