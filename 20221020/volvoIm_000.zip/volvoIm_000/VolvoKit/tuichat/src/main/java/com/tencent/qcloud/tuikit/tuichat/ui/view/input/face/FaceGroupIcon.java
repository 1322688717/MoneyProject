package com.tencent.qcloud.tuikit.tuichat.ui.view.input.face;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.tencent.qcloud.tuikit.tuichat.R;


public class FaceGroupIcon extends RelativeLayout {

    private ImageView faceTabIcon;
    private RelativeLayout layout_emoji;

    public FaceGroupIcon(Context context) {
        super(context);
        init();
    }

    public FaceGroupIcon(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public FaceGroupIcon(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        inflater.inflate(R.layout.face_group_icon, this);
        faceTabIcon = findViewById(R.id.face_group_tab_icon);
        //feifei 表情包入口设置
        layout_emoji = findViewById(R.id.layout_emoji);
        layout_emoji.setVisibility(GONE);
    }

    public void setFaceTabIcon(Bitmap bitmap) {
        faceTabIcon.setImageBitmap(bitmap);
    }
}
