package com.tencent.qcloud.tuikit.tuichat.bean;

import java.io.Serializable;
import java.util.List;

/**
 * 自定义消息的bean实体，用来与json的相互转化
 */

public class CustomVolvoSatisfactionMessage implements Serializable {

    /**
     * session_id : a30fbcbf-ea2d-48f7-822d-80f6f722ba15
     * businessID : satisfaction_survey_msg
     * title : 满意度评价
     * desc : 为了更好的为您提供服务，请您对我们的服务进⾏评价。
     * finish_state : 0
     * expireDate : 0
     * quesions : [{"question_content":"您的问题是否已解决？","question_id":"solve","answers":[{"answer_content":"已解决","answer_id":1,"select":0},{"answer_content":"未解决","answer_id":2,"select":0}]},{"question_content":"您对我们的服务满意吗？","question_id":"satisfied","answers":[{"answer_content":"满意","answer_id":2,"select":0},{"answer_content":"⼀般","answer_id":3,"select":0},{"answer_content":"不满意","answer_id":4,"select":0}]}]
     */

    private String session_id;
    private String businessID;
    private String title;
    private String desc;
    private Integer finish_state;
    private long expireDate;
    private List<QuesionsBean> quesions;

    public static class QuesionsBean implements Serializable {
        /**
         * question_content : 您的问题是否已解决？
         * question_id : solve
         * answers : [{"answer_content":"已解决","answer_id":1,"select":0},{"answer_content":"未解决","answer_id":2,"select":0}]
         */

        private String question_content;
        private String question_id;
        private List<AnswersBean> answers;

        public static class AnswersBean implements Serializable {
            /**
             * answer_content : 已解决
             * answer_id : 1
             * select : 0
             */

            private String answer_content;
            private Integer answer_id;
            private Integer select;
            private boolean isSelectCheck;

            public boolean isSelectCheck() {
                return isSelectCheck;
            }

            public void setSelectCheck(boolean selectCheck) {
                isSelectCheck = selectCheck;
            }

            public String getAnswer_content() {
                return answer_content;
            }

            public void setAnswer_content(String answer_content) {
                this.answer_content = answer_content;
            }

            public Integer getAnswer_id() {
                return answer_id;
            }

            public void setAnswer_id(Integer answer_id) {
                this.answer_id = answer_id;
            }

            public Integer getSelect() {
                return select;
            }

            public void setSelect(Integer select) {
                this.select = select;
            }
        }

        public String getQuestion_content() {
            return question_content;
        }

        public void setQuestion_content(String question_content) {
            this.question_content = question_content;
        }

        public String getQuestion_id() {
            return question_id;
        }

        public void setQuestion_id(String question_id) {
            this.question_id = question_id;
        }

        public List<AnswersBean> getAnswers() {
            return answers;
        }

        public void setAnswers(List<AnswersBean> answers) {
            this.answers = answers;
        }
    }

    public String getSession_id() {
        return session_id;
    }

    public void setSession_id(String session_id) {
        this.session_id = session_id;
    }

    public String getBusinessID() {
        return businessID;
    }

    public void setBusinessID(String businessID) {
        this.businessID = businessID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Integer getFinish_state() {
        return finish_state;
    }

    public void setFinish_state(Integer finish_state) {
        this.finish_state = finish_state;
    }

    public long getExpireDate() {
        return expireDate;
    }

    public void setExpireDate(Integer expireDate) {
        this.expireDate = expireDate;
    }

    public List<QuesionsBean> getQuesions() {
        return quesions;
    }

    public void setQuesions(List<QuesionsBean> quesions) {
        this.quesions = quesions;
    }
}
