package com.tencent.qcloud.tuikit.tuichat.bean.message;

import com.google.gson.Gson;
import com.tencent.imsdk.v2.V2TIMMessage;
import com.tencent.qcloud.tuikit.tuichat.R;
import com.tencent.qcloud.tuikit.tuichat.TUIChatService;
import com.tencent.qcloud.tuikit.tuichat.bean.CustomHelloMessage;
import com.tencent.qcloud.tuikit.tuichat.bean.CustomHelloVolvoMessage;
import com.tencent.qcloud.tuikit.tuichat.bean.message.reply.CustomLinkReplyQuoteBean;
import com.tencent.qcloud.tuikit.tuichat.bean.message.reply.TUIReplyQuoteBean;

/**
 * 自定义超链接消息
 */
public class CustomLinkMessageVolvoBean extends TUIMessageBean {

    private CustomHelloVolvoMessage customHelloVolvoMessage;

    @Override
    public String onGetDisplayString() {
        return getText();
    }

    @Override
    public void onProcessMessage(V2TIMMessage v2TIMMessage) {
//        String data = new String(v2TIMMessage.getCustomElem().getData());
        String data = v2TIMMessage.getCustomElem().getDescription();
        customHelloVolvoMessage = new Gson().fromJson(data, CustomHelloVolvoMessage.class);
        if (customHelloVolvoMessage != null) {
            setExtra(customHelloVolvoMessage.text);
        } else {
            String text = TUIChatService.getAppContext().getString(R.string.no_support_msg);
            setExtra(text);
        }
    }

    public String getText() {
        if (customHelloVolvoMessage != null) {
            return customHelloVolvoMessage.text;
        }
        return getExtra();
    }

//    public String getLink() {
//        if (customHelloVolvoMessage != null) {
//            return customHelloVolvoMessage.link;
//        }
//        return "";
//    }

    @Override
    public Class<? extends TUIReplyQuoteBean> getReplyQuoteBeanClass() {
        return CustomLinkReplyQuoteBean.class;
    }
}
