package com.tencent.qcloud.tuikit.tuichat.bean.message;

import com.google.gson.Gson;
import com.tencent.imsdk.v2.V2TIMMessage;
import com.tencent.qcloud.tuikit.tuichat.R;
import com.tencent.qcloud.tuikit.tuichat.TUIChatService;
import com.tencent.qcloud.tuikit.tuichat.bean.CustomMessageVolvoProductMessage;
import com.tencent.qcloud.tuikit.tuichat.bean.message.reply.CustomLinkReplyQuoteBean;
import com.tencent.qcloud.tuikit.tuichat.bean.message.reply.TUIReplyQuoteBean;
import com.tencent.qcloud.tuikit.tuichat.util.TUIChatLog;
import com.tencent.qcloud.tuikit.tuichat.util.TUIChatUtils;

/**
 * 商品信息Bean
 */
public class CustomMessageVolvoProductBean extends TUIMessageBean {

    private CustomMessageVolvoProductMessage customHelloVolvoMessage;

    @Override
    public String onGetDisplayString() {
        return getText();
    }

    @Override
    public void onProcessMessage(V2TIMMessage v2TIMMessage) {
//        String data = new String(v2TIMMessage.getCustomElem().getData());
        String data = v2TIMMessage.getCustomElem().getDescription();
        TUIChatLog.i("customMessage==",data);
        if(TUIChatUtils.isContentJson(data)){
            customHelloVolvoMessage = new Gson().fromJson(data, CustomMessageVolvoProductMessage.class);
        }
        if (customHelloVolvoMessage != null) {
            setExtra(data);
        } else {
            String text = TUIChatService.getAppContext().getString(R.string.no_support_msg);
            setExtra(text);
        }
    }

    public String getText() {
        return getExtra();
    }

    @Override
    public Class<? extends TUIReplyQuoteBean> getReplyQuoteBeanClass() {
        return CustomLinkReplyQuoteBean.class;
    }
}
