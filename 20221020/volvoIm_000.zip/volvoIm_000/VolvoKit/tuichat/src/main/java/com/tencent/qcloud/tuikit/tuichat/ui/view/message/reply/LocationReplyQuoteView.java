package com.tencent.qcloud.tuikit.tuichat.ui.view.message.reply;

import android.content.Context;

import com.tencent.qcloud.tuikit.tuichat.bean.message.reply.TUIReplyQuoteBean;

public class LocationReplyQuoteView extends TUIReplyQuoteView {
    @Override
    public int getLayoutResourceId() {
        return 0;
    }

    public LocationReplyQuoteView(Context context) {
        super(context);
    }

    @Override
    public void onDrawReplyQuote(TUIReplyQuoteBean quoteBean) {

    }
}
