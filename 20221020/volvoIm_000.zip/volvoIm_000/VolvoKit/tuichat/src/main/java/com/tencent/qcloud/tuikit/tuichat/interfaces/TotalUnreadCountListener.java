package com.tencent.qcloud.tuikit.tuichat.interfaces;

public interface TotalUnreadCountListener {
    void onTotalUnreadCountChanged(long totalUnreadCount);
}
