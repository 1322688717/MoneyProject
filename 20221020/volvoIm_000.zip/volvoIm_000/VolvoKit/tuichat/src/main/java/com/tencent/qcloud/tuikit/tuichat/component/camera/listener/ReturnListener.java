package com.tencent.qcloud.tuikit.tuichat.component.camera.listener;

public interface ReturnListener {
    void onReturn();
}
