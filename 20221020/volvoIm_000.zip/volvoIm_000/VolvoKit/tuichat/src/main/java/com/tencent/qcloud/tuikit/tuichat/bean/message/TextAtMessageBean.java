package com.tencent.qcloud.tuikit.tuichat.bean.message;

/**
 * at 消息
 */
public class TextAtMessageBean extends TextMessageBean {
}
