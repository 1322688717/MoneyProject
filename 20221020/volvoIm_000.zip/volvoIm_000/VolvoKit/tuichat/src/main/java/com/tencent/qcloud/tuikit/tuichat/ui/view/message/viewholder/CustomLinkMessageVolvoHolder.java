package com.tencent.qcloud.tuikit.tuichat.ui.view.message.viewholder;

import android.content.Context;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.tencent.qcloud.tuicore.TUIThemeManager;
import com.tencent.qcloud.tuikit.tuichat.R;
import com.tencent.qcloud.tuikit.tuichat.bean.message.CustomLinkBean;
import com.tencent.qcloud.tuikit.tuichat.bean.message.CustomLinkMessageVolvoBean;
import com.tencent.qcloud.tuikit.tuichat.bean.message.TUIMessageBean;
import com.tencent.qcloud.tuikit.tuichat.util.TUIChatUtils;
import com.tencent.qcloud.util.VolvoChatCallback;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 自定义消息欢迎消息
 */
public class CustomLinkMessageVolvoHolder extends MessageContentHolder {
    private TextView textView;

    public CustomLinkMessageVolvoHolder(View itemView) {
        super(itemView);
        textView = itemView.findViewById(R.id.test_custom_message_volvo_tv);
    }

    public static final String TAG = CustomLinkMessageVolvoHolder.class.getSimpleName();

    @Override
    public int getVariableLayout() {
        return R.layout.test_custom_message_volvo_layout1;
    }

    @Override
    public void layoutVariableViews(TUIMessageBean msg, int position) {
        // 自定义消息view的实现，这里仅仅展示文本信息，并且实现超链接跳转
        String text = "";
        if (msg instanceof CustomLinkMessageVolvoBean) {
            text = msg.getExtra();
        }

        if (!msg.isSelf()) {
            textView.setTextColor(textView.getResources().getColor(TUIThemeManager.getAttrResId(textView.getContext(), R.attr.chat_other_custom_msg_text_color)));
        } else {
            textView.setTextColor(textView.getResources().getColor(TUIThemeManager.getAttrResId(textView.getContext(), R.attr.chat_self_custom_msg_text_color)));
        }

        String[] aa = text.split("<\\[=");
        List<String> realJsonList = new ArrayList<>();
        for (int i = 0;i<aa.length;i++){
            String[] bb = aa[i].split("=]>");
            if(bb.length>0 && TUIChatUtils.isContentJson(bb[0])){
                realJsonList.add(bb[0]);
            }
        }
        List<String> showLinkName = new ArrayList<>();
        String endShowString = text;
        for(int i = 0;i<realJsonList.size();i++){
            if(TUIChatUtils.isContentJson(realJsonList.get(i))){
                CustomLinkBean linkBean = new Gson().fromJson(realJsonList.get(i),CustomLinkBean.class);
                showLinkName.add(linkBean.getName());
                if(text.contains(getReplaceJson(realJsonList.get(i)))){
                    endShowString = endShowString.replace(getReplaceJson(realJsonList.get(i)),linkBean.getName());
                }
            }
        }
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setText(generateSp(itemView.getContext(),endShowString,showLinkName,realJsonList));
    }
    //设置点击数时间
    private CharSequence generateSp(Context mContext, String showContent, List<String> targetList, List<String> jsonContentList){
        SpannableString sp = new SpannableString(showContent);
        int index = 0;
        int start = 0,end;
        for(int i = 0;i<targetList.size();i++){
            start = 0;
            while ((index = showContent.indexOf(targetList.get(i), start)) > -1){
                end = index+targetList.get(i).length();
                int finalI = i;
                ClickableSpan what = new ClickableSpan() {
                    @Override
                    public void onClick(@NonNull View view) {
                        if(null != VolvoChatCallback.volvoChatListener && mContext instanceof AppCompatActivity){
                            VolvoChatCallback.volvoChatListener.onLinkClick((AppCompatActivity)mContext,jsonContentList.get(finalI));
                        }
                        if (null != VolvoChatCallback.volvoEventListener) {
                            try {
                                JSONObject jsonObject = new JSONObject(jsonContentList.get(finalI));
                                String linkName = jsonObject.getString("name");

                                Map<String, String> buriedPoint = new HashMap<>();
                                buriedPoint.put("page_title", "在线客服");
                                buriedPoint.put("btn_type", "btn");
                                buriedPoint.put("btn_name", linkName);
                                JSONObject jsonData = new JSONObject(buriedPoint.toString());
                                VolvoChatCallback.volvoEventListener.trackEventWithProperties("Button_click", jsonData);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    @Override
                    public void updateDrawState(@NonNull TextPaint ds) {
                        super.updateDrawState(ds);
                        ds.setUnderlineText(false);
                        ds.setColor(textView.getResources().getColor(TUIThemeManager.getAttrResId(textView.getContext(), R.attr.chat_self_custom_msg_link_color)));
                    }
                };
                sp.setSpan(what,index,end,Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
                start = end;
            }
        }
        return sp;
    }

    private String getReplaceJson(String jsonString){
        return "<[="+jsonString+"=]>";
    }
}
