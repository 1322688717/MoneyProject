package com.tencent.qcloud.tuikit.tuichat.ui.view.message.viewholder;

import static com.tencent.imsdk.BaseConstants.ERR_SDK_MSG_MODIFY_CONFLICT;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.tencent.imsdk.v2.V2TIMCompleteCallback;
import com.tencent.imsdk.v2.V2TIMManager;
import com.tencent.imsdk.v2.V2TIMMessage;
import com.tencent.qcloud.http.MposRequest;
import com.tencent.qcloud.http.NetworkCallback;
import com.tencent.qcloud.tuicore.util.ToastUtil;
import com.tencent.qcloud.tuikit.tuichat.R;
import com.tencent.qcloud.tuikit.tuichat.TUIChatService;
import com.tencent.qcloud.tuikit.tuichat.bean.CustomVolvoSatisfactionMessage;
import com.tencent.qcloud.tuikit.tuichat.bean.SatisfactionBean;
import com.tencent.qcloud.tuikit.tuichat.bean.message.CustomMessageVolvoSatisfactionBean;
import com.tencent.qcloud.tuikit.tuichat.bean.message.TUIMessageBean;
import com.tencent.qcloud.tuikit.tuichat.ui.view.SatisfactionGrideView;
import com.tencent.qcloud.tuikit.tuichat.ui.view.message.SatisfactionQuesionAdapter;
import com.tencent.qcloud.tuikit.tuichat.util.ChatMessageParser;
import com.tencent.qcloud.tuikit.tuichat.util.TUIChatLog;
import com.tencent.qcloud.util.SpUtil;
import com.tencent.qcloud.util.VolvoChatCallback;
import com.tencent.qcloud.util.VolvoImConstant;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 自定义消息
 * 满意度调查
 */
public class CustomMessageVolvoSatisfactionHolder extends MessageContentHolder{

    private TextView volvo_satis_title, volvo_satis_desc,
             volvo_satis_submit;
    private LinearLayout volvo_layout_satisfaction;
    private LinearLayout layout_satis_quesion;
    //满意度调查消息信息
    private CustomVolvoSatisfactionMessage messageBean;
    //是否正在提交
    private boolean isSubmitting;

    public CustomMessageVolvoSatisfactionHolder(View itemView) {
        super(itemView);
        volvo_satis_title = itemView.findViewById(R.id.volvo_satis_title);
        volvo_satis_desc = itemView.findViewById(R.id.volvo_satis_desc);
        volvo_satis_submit = itemView.findViewById(R.id.volvo_satis_submit);
        volvo_layout_satisfaction = itemView.findViewById(R.id.volvo_layout_satisfaction);
        layout_satis_quesion = itemView.findViewById(R.id.layout_satis_quesion);
    }

    public static final String TAG = CustomMessageVolvoSatisfactionHolder.class.getSimpleName();

    @Override
    public int getVariableLayout() {
        return R.layout.test_custom_message_volvo_satisfaction;
    }

    @Override
    public void layoutVariableViews(TUIMessageBean msg, int position) {
        String text = "";
        if (msg instanceof CustomMessageVolvoSatisfactionBean) {
            text = msg.getExtra();
        }
        try {
            messageBean = new Gson().fromJson(text, CustomVolvoSatisfactionMessage.class);
            if (null != messageBean) {
                volvo_layout_satisfaction.setVisibility(View.VISIBLE);
                volvo_satis_title.setText(messageBean.getTitle());
                volvo_satis_desc.setText(messageBean.getDesc());
                //动态添加问题
                layout_satis_quesion.removeAllViews();
                /**
                 * 不能选择，设置选项不可点击
                 *  1、当前时间戳大于到期时间戳，已过期不再设置
                 *  2、finish_state  0： 未提交    1：已提交
                 */
                boolean isCanClickCheck;
                if(getTimestamp() >messageBean.getExpireDate() || 1 == messageBean.getFinish_state()){
                    isCanClickCheck = false;
                    //隐藏提交按钮
                    volvo_satis_submit.setVisibility(View.GONE);
                }else{
                    isCanClickCheck = true;
                    //隐藏提交按钮
                    volvo_satis_submit.setVisibility(View.VISIBLE);
                }
                getQuestionView(messageBean.getQuesions(),isCanClickCheck);
            }
            volvo_satis_submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(isSubmitting){
                        return;
                    }
                    int selectNummber = 0;
                    Map<String,Object> params = new HashMap<>();
                    params.put("sessionId", SpUtil.getInstance().getString(VolvoImConstant.SP_CUSTOMER_SERVICEID));

                    if(null != messageBean.getQuesions()){
                        for(int i = 0;i<messageBean.getQuesions().size();i++){
                            CustomVolvoSatisfactionMessage.QuesionsBean quesionsBean = messageBean.getQuesions().get(i);
                            for(int d = 0;d<quesionsBean.getAnswers().size();d++){
                                if(1 ==quesionsBean.getAnswers().get(d).getSelect()){
                                    params.put(quesionsBean.getQuestion_id(),quesionsBean.getAnswers().get(d).getAnswer_id());
                                    selectNummber++;
                                }
                            }
                        }
                    }
                    //判断选择完成
                    if(selectNummber != messageBean.getQuesions().size()){
                        ToastUtil.toastShortMessage(TUIChatService.getAppContext().getString(R.string.chat_msg_satisfaction_prompt_lau));
                        return;
                    }
                    TUIChatLog.i("Satisfaction","当前参数=="+params.toString());
                    /**
                     * 提交满意度调查结果到4合1
                     */
                    isSubmitting = true;
                     MposRequest.getInstance().httpSubmitSaticfaction(params, new NetworkCallback() {
                        @Override
                        public void success(String result) {
                            TUIChatLog.i("TAG MESSAGE==接口成功==",result);
                            try {
                                SatisfactionBean satisfactionBean = new Gson().fromJson(result,SatisfactionBean.class);
                                if("200".equals(satisfactionBean.getReturnCode())){
                                    tencentModify(msg);
                                }else{
                                    isSubmitting = false;
                                    ToastUtil.toastShortMessage(satisfactionBean.getMessage());
                                }
                            }catch (Exception e){
                                isSubmitting = false;
                            }
                        }

                        @Override
                        public void error(int errorCode, String errormsg) {
                            isSubmitting = false;
                        }
                    });
                }
            });

        } catch (Exception e) {
            volvo_layout_satisfaction.setVisibility(View.GONE);
        }
    }

    private void getQuestionView(List<CustomVolvoSatisfactionMessage.QuesionsBean> quesionsBeans,boolean isCanCLick){
        for(int i = 0;i<quesionsBeans.size();i++){
            View quesionView = LayoutInflater.from(itemView.getContext()).inflate(R.layout.volvo_satisfaction_quesion_view,null);
            CustomVolvoSatisfactionMessage.QuesionsBean quesion = quesionsBeans.get(i);
            TextView volvo_tv_question_solve = quesionView.findViewById(R.id.volvo_tv_question_solve);
            volvo_tv_question_solve.setText(quesion.getQuestion_content());
            SatisfactionGrideView volvo_satisquesion_grideview = quesionView.findViewById(R.id.volvo_satisquesion_grideview);
            SatisfactionQuesionAdapter quesionAdapter = new SatisfactionQuesionAdapter(itemView.getContext(),quesion.getAnswers(),isCanCLick);
            volvo_satisquesion_grideview.setAdapter(quesionAdapter);
//            volvo_satisquesion_grideview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                @Override
//                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
////                    ToastUtil.toastShortMessage(quesion.getAnswers().get(i).getAnswer_content());
//                }
//            });
            layout_satis_quesion.addView(quesionView);
        }

    }

    /**
     * 调用腾讯修改消息的方法
     */
    private void tencentModify(TUIMessageBean msg){
        //获取修改后的消息
        CustomVolvoSatisfactionMessage modifyBean =messageBean;
        modifyBean.setFinish_state(1);
        String submitJson = new Gson().toJson(modifyBean);
//        TUIChatLog.i("CustomMessageVolvoSatisfactionHolder==当前= ", msg.getV2TIMMessage().getCustomElem().getDescription());
        //重新设置自定义消息内容
        V2TIMMessage modifyMsg = msg.getV2TIMMessage();
        modifyMsg.getCustomElem().setDescription(submitJson);
        modifyMsg.getCustomElem().setData(submitJson.getBytes());
//        TUIChatLog.i("CustomMessageVolvoSatisfactionHolder==改后= ",submitJson);
        V2TIMManager.getMessageManager().modifyMessage(modifyMsg, new V2TIMCompleteCallback<V2TIMMessage>() {
            @Override
            public void onComplete(int code, String desc, V2TIMMessage v2TIMMessage) {
                isSubmitting = false;
                //埋点回调
                if (null != VolvoChatCallback.volvoEventListener) {
                    try {
                        Map<String, String> buriedPoint = new HashMap<>();
                        buriedPoint.put("page_title", "在线客服");
                        buriedPoint.put("btn_type", "btn");
                        buriedPoint.put("btn_name", "满意度评价");
                        JSONObject jsonData = new JSONObject(buriedPoint.toString());
                        VolvoChatCallback.volvoEventListener.trackEventWithProperties("Button_click", jsonData);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                TUIMessageBean modifiedMessage = ChatMessageParser.parseMessage(v2TIMMessage);
                if (code == ERR_SDK_MSG_MODIFY_CONFLICT) {
                } else {
                }
            }
        });
    }

    /**
     * 获取时间戳，单位为秒
     * @return
     */
    private long getTimestamp(){
        long currentTimeLong = System.currentTimeMillis();
        String currentTime = String.valueOf(currentTimeLong);
        if(currentTime.length()>3){
            return Long.valueOf(currentTime.substring(0,currentTime.length()-3));
        }
        return Long.valueOf(currentTimeLong);
    }
}
