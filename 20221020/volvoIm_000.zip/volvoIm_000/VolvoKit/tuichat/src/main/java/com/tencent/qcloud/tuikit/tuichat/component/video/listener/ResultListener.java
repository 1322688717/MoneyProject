package com.tencent.qcloud.tuikit.tuichat.component.video.listener;

public interface ResultListener {
    void callback();
}
