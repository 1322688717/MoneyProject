package com.tencent.qcloud.tuikit.tuichat.bean;

import java.io.Serializable;

public class SatisfactionBean implements Serializable {

    /**
     * data : null
     * returnCode : 200
     * message : 成功
     */

    private Object data;
    private String returnCode;
    private String message;

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
