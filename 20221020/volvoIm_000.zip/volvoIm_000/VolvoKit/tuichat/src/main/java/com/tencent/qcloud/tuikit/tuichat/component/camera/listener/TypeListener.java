package com.tencent.qcloud.tuikit.tuichat.component.camera.listener;

public interface TypeListener {
    void cancel();

    void confirm();
}
