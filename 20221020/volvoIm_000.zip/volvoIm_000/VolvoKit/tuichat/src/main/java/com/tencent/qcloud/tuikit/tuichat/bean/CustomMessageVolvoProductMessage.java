package com.tencent.qcloud.tuikit.tuichat.bean;

import java.io.Serializable;

/**
 * 自定义消息
 *  商品信息,用来与json的相互转化
 */
public class CustomMessageVolvoProductMessage implements Serializable {

    private String businessID;
    private ProductInfoBean product_info;

    public static class ProductInfoBean implements Serializable{
        private String product_name;
        private String product_price;
        private String v_value;
        private String product_img;
        private String spuId;

        public String getSpuId() {
            return spuId;
        }

        public void setSpuId(String spuId) {
            this.spuId = spuId;
        }

        public String getProduct_name() {
            return product_name;
        }

        public void setProduct_name(String product_name) {
            this.product_name = product_name;
        }

        public String getProduct_price() {
            return product_price;
        }

        public void setProduct_price(String product_price) {
            this.product_price = product_price;
        }

        public String getV_value() {
            return v_value;
        }

        public void setV_value(String v_value) {
            this.v_value = v_value;
        }

        public String getProduct_img() {
            return product_img;
        }

        public void setProduct_img(String product_img) {
            this.product_img = product_img;
        }
    }

    public String getBusinessID() {
        return businessID;
    }

    public void setBusinessID(String businessID) {
        this.businessID = businessID;
    }

    public ProductInfoBean getProduct_info() {
        return product_info;
    }

    public void setProduct_info(ProductInfoBean product_info) {
        this.product_info = product_info;
    }
}
