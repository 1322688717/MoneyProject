package com.tencent.qcloud.tuikit.tuichat.ui.page;

import android.os.Bundle;

import androidx.annotation.Nullable;

import com.tencent.qcloud.http.MposRequest;
import com.tencent.qcloud.http.NetworkCallback;
import com.tencent.qcloud.tuicore.util.ToastUtil;
import com.tencent.qcloud.tuikit.tuichat.R;
import com.tencent.qcloud.tuikit.tuichat.TUIChatConstants;
import com.tencent.qcloud.tuikit.tuichat.bean.ChatInfo;
import com.tencent.qcloud.tuikit.tuichat.presenter.C2CChatPresenter;
import com.tencent.qcloud.tuikit.tuichat.util.TUIChatLog;
import com.tencent.qcloud.tuikit.tuichat.util.TUIChatUtils;
import com.tencent.qcloud.util.SpUtil;
import com.tencent.qcloud.util.VolvoChatCallback;
import com.tencent.qcloud.util.VolvoImConstant;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class TUIC2CChatActivity extends TUIBaseChatActivity {
    private static final String TAG = TUIC2CChatActivity.class.getSimpleName();

    private TUIC2CChatFragment chatFragment;
    private C2CChatPresenter presenter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //记录会话进入时间戳
        VolvoImConstant.buriedStartTime = System.currentTimeMillis();
    }

    @Override
    public void initChat(ChatInfo chatInfo) {
        TUIChatLog.i(TAG, "inti chat " + chatInfo);
        if (!TUIChatUtils.isC2CChat(chatInfo.getType())) {
            TUIChatLog.e(TAG, "init C2C chat failed , chatInfo = " + chatInfo);
            ToastUtil.toastShortMessage("init c2c chat failed.");
        }
        chatFragment = new TUIC2CChatFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable(TUIChatConstants.CHAT_INFO, chatInfo);
        chatFragment.setArguments(bundle);
        presenter = new C2CChatPresenter();
        presenter.initListener();
        chatFragment.setPresenter(presenter);
        getSupportFragmentManager().beginTransaction().replace(R.id.empty_view, chatFragment).commitAllowingStateLoss();
        //欢迎消息获取
        requestWelcomeMessage();
    }

    //请求欢迎消息
    private void requestWelcomeMessage() {
        Map<String, Object> loginParams = new HashMap<>();
        loginParams.put(VolvoImConstant.VOLVO_MEMBERID, SpUtil.getInstance().getString(VolvoImConstant.SP_MEMBERID));
        loginParams.put(VolvoImConstant.VOLVO_MEMBERNAME, SpUtil.getInstance().getString(VolvoImConstant.SP_MEMBERNAME));
        loginParams.put(VolvoImConstant.VOLVO_MEMBERURL, SpUtil.getInstance().getString(VolvoImConstant.SP_MEMBERURL));
        //是否为demo调试
        if (SpUtil.getInstance().getBoolean(VolvoImConstant.SP_ISDEMOTEST, false)) {
            //测试调用
            MposRequest.getInstance().getDemoLoginInfo(loginParams, 0, new NetworkCallback() {
                @Override
                public void success(String result) {
                    TUIChatLog.i("demo调试", "成功==" + result);
                }

                @Override
                public void error(int errorCode, String errormsg) {
                    TUIChatLog.i("demo调试", "得到信息失败==" + errorCode + "   " + errormsg);
                }
            });
        } else {
            //bff接口调用
            MposRequest.getInstance().getVolvoLoginInfo(loginParams, 0, null);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        VolvoImConstant.lastTimeMapParams = null;
        if (null != VolvoChatCallback.volvoEventListener) {
            try {
                Map<String, String> buriedPoint = new HashMap<>();
                buriedPoint.put("page_title", "在线客服");
//                int durationTime = (int) ((System.currentTimeMillis() - VolvoImConstant.buriedStartTime)/1000);
                buriedPoint.put("view_duration", (System.currentTimeMillis() - VolvoImConstant.buriedStartTime)+"");
                JSONObject jsonData = new JSONObject(buriedPoint.toString());
                VolvoChatCallback.volvoEventListener.trackEventWithProperties("Page_view", jsonData);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
