package com.volvo.im;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.tencent.imsdk.v2.V2TIMSDKConfig;
import com.tencent.qcloud.tuicore.util.ToastUtil;
import com.tencent.qcloud.util.VIMEntranceType;
import com.tencent.qcloud.util.VolvoChatCallback;
import com.tencent.qcloud.util.VolvoImConstant;
import com.volvo.tencentim.VolvoImKit;
import com.volvo.tencentim.VolvoSDKConfig;
import com.volvo.tencentim.callback.UnReadMessageListener;
import com.volvo.tencentim.callback.VolvoImCallback;
import com.volvo.tencentim.utils.LogUtils;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private String mainTag = MainActivity.class.getSimpleName();

    Button btn_login, btn_jumpChat, btn_logOut,btn_orderChat,btn_pushToChat,
            btn_getUnReadNummber,btn_demoLogin,btn_product,btn_refreshHeader;
    EditText et_memberId,et_memberName;

//    private String testJson = "{\"businessID\":\"satisfaction_survey_msg\",\"desc\":\"为了更好的为您提供服务，请您对我们的服务进⾏评价。\",\"expireDate\":0,\"finish_state\":1,\"quesions\":[{\"answers\":[{\"answer_content\":\"已解决\",\"answer_id\":1,\"select\":1},{\"answer_content\":\"未解决\",\"answer_id\":2,\"select\":0}],\"question_content\":\"您的问题是否已解决？\",\"question_id\":\"solve\"},{\"answers\":[{\"answer_content\":\"满意\",\"answer_id\":2,\"select\":0},{\"answer_content\":\"⼀般\",\"answer_id\":3,\"select\":1},{\"answer_content\":\"不满意\",\"answer_id\":4,\"select\":0}],\"question_content\":\"您对我们的服务满意吗？\",\"question_id\":\"satisfied\"}],\"session_id\":\"a30fbcbf-ea2d-48f7-822d-80f6f722ba15\",\"title\":\"满意度评价\"}";
    private String testJson = "哈哈哈哈";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        et_memberId.setText("");
        et_memberName.setText("");
        //初始化参数设置
        VolvoSDKConfig config = new VolvoSDKConfig();
        config.packaggeName = getPackageName();
        config.logLevel = V2TIMSDKConfig.V2TIM_LOG_INFO;
        VolvoImKit.get().initIm(getApplication(),config);
        //会话页面监听
        VolvoImKit.get().setOnVolvoChatListener(chatListener);
        VolvoImKit.get().setOnVolvoEventListener(eventListener);
//        SpUtil
    }

    @Override
    protected void onResume() {
        super.onResume();
        VolvoImKit.get().registerUnreadListener();
//        TuiLogUtil.i("测试library内容");
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            //demo登录
            case R.id.btn_demoLogin:
                Map<String,Object> demoPrams = new HashMap<>();
                demoPrams.put(VolvoImConstant.VOLVO_MEMBERID,et_memberId.getText().toString());
                demoPrams.put(VolvoImConstant.VOLVO_MEMBERNAME,et_memberName.getText().toString());
                demoPrams.put(VolvoImConstant.VOLVO_MEMBERURL,"https://newbie-test-dms.digitalvolvo.com/images/2022/05/29/1653800586901e646a5b40c98316c4b68de4dcfdcb32b2cb8551a604658b04bd793102be8e91f.IMG20220307173806.jpg");
//                VolvoImKit.get().showLoading(MainActivity.this);
//                VolvoImKit.get().loginDemo(demoPrams, new VolvoImCallback() {
//                    @Override
//                    public void onSuccess() {
//                        VolvoImKit.get().hideLoading();
//                        LogUtils.debugInfo("登录成功===");
//                   }
//
//                    @Override
//                    public void onError(int errorCode, String errorMessage) {
//                        VolvoImKit.get().hideLoading();
//                        LogUtils.debugInfo("登录失败==="+errorCode+"  "+errorMessage);
//
//                    }
//                });
                break;
            //APP接入登录登录
            case R.id.btn_login:
                //APP接入地址
                Map<String,Object> loginPrams = new HashMap<>();
                loginPrams.put(VolvoImConstant.VOLVO_MEMBERID,"");
                loginPrams.put(VolvoImConstant.VOLVO_MEMBERNAME,et_memberName.getText().toString());
                loginPrams.put(VolvoImConstant.VOLVO_MEMBERURL,"https://newbie-test-dms.digitalvolvo.com/images/2022/06/30/1656568236258d53b27f3351ec53c4173b462be0581384de2e8694f953ded9f68d14a231befc2.Screenshot_20220610_132417_com.taobao.taobao.jpg");
                //token设置
                loginPrams.put("Authorization","");
                loginPrams.put("X-Token","");
//                VolvoImKit.get().showLoading(MainActivity.this);
//                VolvoImKit.get().loginVolvoIm(loginPrams,new VolvoImCallback() {
//                    @Override
//                    public void onSuccess() {
//                        VolvoImKit.get().hideLoading();
//                        //登录成功处理
//                    }
//
//                    @Override
//                    public void onError(int errorCode, String errorMessage) {
//                        VolvoImKit.get().hideLoading();
//                        //登录失败处理
//                        LogUtils.debugInfo("得到信息=错误=="+errorCode + "   "+errorMessage);
//                    }
//                });
                break;
            //个人中心
            case R.id.btn_jumpChat:
//                //更新头型地址
                VolvoImKit.get().refreshNewHeader("https://newbie-test-dms.digitalvolvo.com/images/2022/08/06/1659766206230a2b16a6fbd2a97a7aaca1a037f188c75848ff2dd1208ad97ab001288ebdbfc16.1644561379133.jpg");
                //打开会话页面
                VolvoImKit.get().openChat(VIMEntranceType.PersonalCenter);

                break;
            //订单详情入口会话
            case R.id.btn_orderChat:
                Map<String,String> orderParams = new HashMap<>();
                orderParams.put("orderType","售后订单");
                orderParams.put("orderID","1234567");
                VolvoImKit.get().openChat(VIMEntranceType.Order,orderParams);
                break;
            //商品详情
            case R.id.btn_product:
                Map<String,String> productParams = new HashMap<>();
                productParams.put("product_img","https://newbie-test-dms.digitalvolvo.com/images/2022/05/29/1653800586901e646a5b40c98316c4b68de4dcfdcb32b2cb8551a604658b04bd793102be8e91f.IMG20220307173806.jpg");
                productParams.put("product_name","商品名称");
                productParams.put("product_price","2,223");
                productParams.put("v_value","33");
                productParams.put("product_spuId","23232323");
                VolvoImKit.get().openChat(VIMEntranceType.Product,productParams);
                break;
            //推送入口进入会话
            case R.id.btn_pushToChat:
                /**
                 * 消息格式示例：
                 * {
                 * 		"action": 1,
                 * 		"chatType": 1,
                 * 		"content": "最热",
                 * 		"faceUrl": "",
                 * 		"nickname": "北京123",
                 * 		"sendTime": 0,
                 * 		"sender": "aa",
                 * 		"version": 1
                 *        }
                 */
                String offlineMessage = VolvoImKit.get().parseOfflineMsg(getIntent());
//                String offlineMessage = "{\"action\":1,\"chatType\":1,\"content\":\"推送数据\",\"faceUrl\":\"\",\"nickname\":\"北京123\",\"sendTime\":0,\"sender\":\"aa\",\"version\":1}";
//                String offlineMessage = "";
                VolvoImKit.get().openChat(VIMEntranceType.PushMessageBackground,MainActivity.this,offlineMessage);

                break;
            //未读消息数量
            case R.id.btn_getUnReadNummber:
                VolvoImKit.get().getTotalUnRead(new UnReadMessageListener() {
                    @Override
                    public void unReadTotalMessage(int unReadNummber) {
                        ToastUtil.toastShortMessage("未读消息数="+unReadNummber);
                    }
                });

                break;
            //登出
            case R.id.btn_logOut:
                VolvoImKit.get().showLoading(MainActivity.this);
                VolvoImKit.get().logoutIm(new VolvoImCallback() {
                    @Override
                    public void onSuccess() {
                        VolvoImKit.get().hideLoading();
                        //登出成功处理
                    }

                    @Override
                    public void onError(int errorCode, String errorMessage) {
                        VolvoImKit.get().hideLoading();
                        //登出失败处理
                    }
                });
                break;
            //更新请求header
            case R.id.btn_refreshHeader:
                VolvoImKit.get().refreshHeaderToken("AuthorizationToken","x_token");
                break;

        }
    }

    /**
     * 会话监听事件
     */
    VolvoChatCallback.VolvoChatListener chatListener = new VolvoChatCallback.VolvoChatListener(){

        /**
         * 欢迎消息链接点击
         * @param mContext
         * @param linkContent json对象，解析处理跳转
         */
        @Override
        public void onLinkClick(AppCompatActivity mContext,String linkContent) {
                ToastUtil.toastShortMessage(linkContent);
                LogUtils.debugInfo(mainTag+linkContent);
        }

        /**
         * 客服电话
         * @param mContext
         */
        @Override
        public void onCustomerClick(AppCompatActivity mContext) {
                ToastUtil.toastShortMessage("联系客服");
               LogUtils.debugInfo(mainTag+"联系客服");
        }

        /**
         * 会话开始
         */
        @Override
        public void onConversationStart() {
            LogUtils.debugInfo(mainTag+"==会话开始");
        }

        /**
         * 会话结束
         */
        @Override
        public void onConversationEnd() {
            LogUtils.debugInfo(mainTag+"==会话结束");

        }

        /**
         * 商品点击
         * @param mContext
         */
        @Override
        public void onProductClick(AppCompatActivity mContext, String productspuId) {
            ToastUtil.toastShortMessage("商品Id  =="+productspuId);
            LogUtils.debugInfo(mainTag+"商品Id  "+productspuId);
        }

    };

    /**
     * 埋点统计
     */
    VolvoChatCallback.VolvoEventListener eventListener = new VolvoChatCallback.VolvoEventListener() {
        @Override
        public void trackEventWithProperties(String event, JSONObject propertieDict) {
            LogUtils.debugInfo("Event==="+event+"  "+propertieDict.toString());
        }
    };

    private void initView(){
        btn_login = findViewById(R.id.btn_login);
        btn_jumpChat = findViewById(R.id.btn_jumpChat);
        btn_logOut = findViewById(R.id.btn_logOut);
        et_memberId = findViewById(R.id.et_memberId);
        btn_orderChat = findViewById(R.id.btn_orderChat);
        btn_getUnReadNummber = findViewById(R.id.btn_getUnReadNummber);
        btn_pushToChat = findViewById(R.id.btn_pushToChat);
        et_memberName = findViewById(R.id.et_memberName);
        btn_demoLogin = findViewById(R.id.btn_demoLogin);
        btn_product = findViewById(R.id.btn_product);
        btn_product.setOnClickListener(this);
        btn_refreshHeader = findViewById(R.id.btn_refreshHeader);
        btn_refreshHeader.setOnClickListener(this);
        btn_demoLogin.setOnClickListener(this);
        btn_orderChat.setOnClickListener(this);
        btn_pushToChat.setOnClickListener(this);
        btn_login.setOnClickListener(this);
        btn_jumpChat.setOnClickListener(this);
        btn_logOut.setOnClickListener(this);
        btn_getUnReadNummber.setOnClickListener(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        VolvoImKit.get().removeUnreadListener();
    }
}