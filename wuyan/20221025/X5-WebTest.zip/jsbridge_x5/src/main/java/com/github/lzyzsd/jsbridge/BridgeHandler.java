package com.github.lzyzsd.jsbridge;

public interface BridgeHandler {
	
	void handler(String data, CallBackFunction function);

}
