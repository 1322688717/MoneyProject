package com.just.agentweb;

/**
 * @author cenxiaozhong
 * @date 2019/4/13
 * @since 1.0.0
 */
public class WebViewClient extends MiddlewareWebClientBase {
	public WebViewClient() {
	}

}
